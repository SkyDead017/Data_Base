<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// Обработка выхода
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

// Проверяем авторизацию (только для сотрудников)
if (!isset($_SESSION['db_connection']) || $_SESSION['user_role'] !== 'employee') {
    header('Location: index.php');
    exit();
}

// Подключение к базе данных
$mysqli = new mysqli(
    'MySQL-8.0',
    $_SESSION['db_login'],
    $_SESSION['db_password'],
    'AutomotiveManufacturingCompany'
);
if ($mysqli->connect_error) {
    die("Ошибка подключения: " . $mysqli->connect_error);
}

// Получаем список всех таблиц в базе данных
$tables = [];
$result = $mysqli->query("SHOW TABLES");
if ($result) {
    while ($row = $result->fetch_array()) {
        $tables[] = $row[0];
    }
}

// Обработка формы
$selectedTable = '';
$tableData = [];
$columns = [];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['show_table'])) {
    $selectedTable = $mysqli->real_escape_string($_POST['table_name']);
    
    try {
        $result = $mysqli->query("SELECT * FROM `$selectedTable` LIMIT 100");
        if ($result) {
            $tableData = $result->fetch_all(MYSQLI_ASSOC);
            
            if (!empty($tableData)) {
                $columns = array_keys($tableData[0]);
            }
        } else {
            throw new Exception("Ошибка при выполнении запроса: " . $mysqli->error);
        }
    } catch (Exception $e) {
        $error = "Ошибка при загрузке таблицы: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель сотрудника - Автомобилестроительное предприятие</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        select, button {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        select {
            width: 300px;
        }
        button {
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px 20px;
        }
        button[type="submit"] {
            background: #4CAF50;
        }
        button[type="submit"]:hover {
            background: #45a049;
        }
        button[name="logout"] {
            background: #f44336;
        }
        button[name="logout"]:hover {
            background: #d32f2f;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            position: sticky;
            top: 0;
        }
        .error {
            color: red;
            margin: 10px 0;
        }
        .table-container {
            max-height: 500px;
            overflow-y: auto;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Панель сотрудника</h1>
        
        <form method="POST">
            <div class="form-group">
                <label for="table_name">Выберите таблицу:</label>
                <select id="table_name" name="table_name" required>
                    <option value="">-- Выберите таблицу --</option>
                    <?php foreach ($tables as $table): ?>
                        <option value="<?= htmlspecialchars($table) ?>" 
                            <?= ($selectedTable === $table) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($table) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" name="show_table">Показать таблицу</button>
        </form>

        <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($tableData)): ?>
            <h2>Таблица: <?= htmlspecialchars($selectedTable) ?></h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <?php foreach ($columns as $column): ?>
                                <th><?= htmlspecialchars($column) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tableData as $row): ?>
                            <tr>
                                <?php foreach ($row as $value): ?>
                                    <td><?= htmlspecialchars($value) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <!-- Кнопка выхода -->
        <form method="POST" style="margin-top: 20px;">
            <button type="submit" name="logout">Выход</button>
        </form>
    </div>
</body>
</html>