<?php
header('Content-Type: text/html; charset=utf-8');
session_start();

// Обработка выхода
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

// Проверка авторизации
if (!isset($_SESSION['db_connection']) || $_SESSION['user_role'] !== 'chief') {
    header('Location: index.php');
    exit();
}

// Подключение к БД
$mysqli = new mysqli('MySQL-8.0', $_SESSION['db_login'], $_SESSION['db_password'], 'AutomotiveManufacturingCompany');
if ($mysqli->connect_error) {
    die("Ошибка подключения: " . $mysqli->connect_error);
}

// Функции для работы с БД
function getForeignKeyInfo($mysqli, $table) {
    $foreignKeys = [];
    $query = "SELECT COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME 
              FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table' 
              AND REFERENCED_TABLE_NAME IS NOT NULL";
    
    $result = $mysqli->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $foreignKeys[$row['COLUMN_NAME']] = [
                'referenced_table' => $row['REFERENCED_TABLE_NAME'],
                'referenced_column' => $row['REFERENCED_COLUMN_NAME']
            ];
        }
    }
    return $foreignKeys;
}

function findNameField($mysqli, $table) {
    $result = $mysqli->query("SHOW COLUMNS FROM `$table`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            if (preg_match('/name_|surname|product_name|workshop_name|section_name|brigade_name/', $row['Field'])) {
                return $row['Field'];
            }
        }
    }
    return '';
}

function isTimestampField($column) {
    return strpos($column['Default'], 'CURRENT_TIMESTAMP') !== false || 
           strpos($column['Extra'], 'CURRENT_TIMESTAMP') !== false;
}

function validateQueryParams($mysqli, $queryNumber, $params) {
    $errors = [];
    
    switch ($queryNumber) {
        case 1:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            if (!empty($params['category_id']) && !checkIdExists($mysqli, 'category_product', $params['category_id'])) {
                $errors[] = "Категория с ID {$params['category_id']} не существует";
            }
            break;
            
        case 2:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            if (!empty($params['section_id']) && !checkIdExists($mysqli, 'section', $params['section_id'])) {
                $errors[] = "Участок с ID {$params['section_id']} не существует";
            }
            if (!empty($params['category_id']) && !checkIdExists($mysqli, 'category_product', $params['category_id'])) {
                $errors[] = "Категория с ID {$params['category_id']} не существует";
            }
            if (empty($params['start_date']) || empty($params['end_date'])) {
                $errors[] = "Необходимо указать период дат";
            }
            break;
            
        case 3:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            break;
            
        case 4:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            break;
            
        case 5:
            if (empty($params['product_id']) || !checkIdExists($mysqli, 'product', $params['product_id'])) {
                $errors[] = "Изделие с ID {$params['product_id']} не существует";
            }
            break;
            
        case 6:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            if (!empty($params['section_id']) && !checkIdExists($mysqli, 'section', $params['section_id'])) {
                $errors[] = "Участок с ID {$params['section_id']} не существует";
            }
            break;
            
        case 7:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            if (!empty($params['section_id']) && !checkIdExists($mysqli, 'section', $params['section_id'])) {
                $errors[] = "Участок с ID {$params['section_id']} не существует";
            }
            break;
            
        case 8:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            if (!empty($params['category_id']) && !checkIdExists($mysqli, 'category_product', $params['category_id'])) {
                $errors[] = "Категория с ID {$params['category_id']} не существует";
            }
            break;
            
        case 9:
            if (empty($params['product_id']) || !checkIdExists($mysqli, 'product', $params['product_id'])) {
                $errors[] = "Изделие с ID {$params['product_id']} не существует";
            }
            break;
            
        case 10:
            if (empty($params['product_id']) || !checkIdExists($mysqli, 'product', $params['product_id'])) {
                $errors[] = "Изделие с ID {$params['product_id']} не существует";
            }
            break;
            
        case 11:
            if (empty($params['laboratory_id']) || !checkIdExists($mysqli, 'laboratory', $params['laboratory_id'])) {
                $errors[] = "Лаборатория с ID {$params['laboratory_id']} не существует";
            }
            if (empty($params['start_date']) || empty($params['end_date'])) {
                $errors[] = "Необходимо указать период дат";
            }
            break;
            
        case 12:
            if (!empty($params['product_id']) && !checkIdExists($mysqli, 'product', $params['product_id'])) {
                $errors[] = "Изделие с ID {$params['product_id']} не существует";
            }
            if (!empty($params['category_id']) && !checkIdExists($mysqli, 'category_product', $params['category_id'])) {
                $errors[] = "Категория с ID {$params['category_id']} не существует";
            }
            if (!empty($params['laboratory_id']) && !checkIdExists($mysqli, 'laboratory', $params['laboratory_id'])) {
                $errors[] = "Лаборатория с ID {$params['laboratory_id']} не существует";
            }
            if (empty($params['start_date']) || empty($params['end_date'])) {
                $errors[] = "Необходимо указать период дат";
            }
            break;
            
        case 13:
            if (!empty($params['product_id']) && !checkIdExists($mysqli, 'product', $params['product_id'])) {
                $errors[] = "Изделие с ID {$params['product_id']} не существует";
            }
            if (!empty($params['category_id']) && !checkIdExists($mysqli, 'category_product', $params['category_id'])) {
                $errors[] = "Категория с ID {$params['category_id']} не существует";
            }
            if (empty($params['start_date']) || empty($params['end_date'])) {
                $errors[] = "Необходимо указать период дат";
            }
            break;
            
        case 14:
            if (!empty($params['workshop_id']) && !checkIdExists($mysqli, 'workshop', $params['workshop_id'])) {
                $errors[] = "Цех с ID {$params['workshop_id']} не существует";
            }
            if (!empty($params['section_id']) && !checkIdExists($mysqli, 'section', $params['section_id'])) {
                $errors[] = "Участок с ID {$params['section_id']} не существует";
            }
            if (!empty($params['category_id']) && !checkIdExists($mysqli, 'category_product', $params['category_id'])) {
                $errors[] = "Категория с ID {$params['category_id']} не существует";
            }
            break;
    }
    
    return $errors;
}

function checkIdExists($mysqli, $table, $id) {
    $stmt = $mysqli->prepare("SELECT 1 FROM `$table` WHERE id_$table = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Основная логика
$tables = [];
$result = $mysqli->query("SHOW TABLES");
if ($result) {
    while ($row = $result->fetch_array()) {
        $tables[] = $row[0];
    }
}

$selectedTable = '';
$tableData = [];
$columns = [];
$error = '';
$success = '';
$queryResults = [];
$currentQuery = '';
$activeTab = isset($_POST['execute_query']) ? 'queries' : (isset($_POST['show_table']) ? 'tables' : 'tables');

// Обработка действий с таблицами
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_id'])) {
        // Удаление записи
        $table = $mysqli->real_escape_string($_POST['table_name']);
        $id = (int)$_POST['delete_id'];
        
        try {
            $primaryKey = '';
            $res = $mysqli->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
            if ($res && $res->num_rows > 0) {
                $primaryKey = $res->fetch_assoc()['Column_name'];
            }
            
            if ($primaryKey) {
                $stmt = $mysqli->prepare("DELETE FROM `$table` WHERE $primaryKey = ?");
                $stmt->bind_param('i', $id);
                if ($stmt->execute()) {
                    $success = "Запись успешно удалена";
                } else {
                    throw new Exception($mysqli->sqlstate === '45000' ? $mysqli->error : "Ошибка при удалении");
                }
            } else {
                throw new Exception("Не удалось определить первичный ключ");
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    } 
    elseif (isset($_POST['add_record'])) {
        // Добавление записи
        $table = $mysqli->real_escape_string($_POST['table_name']);
        $columnsInfo = [];
        $res = $mysqli->query("SHOW COLUMNS FROM `$table`");
        
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $columnsInfo[] = $row;
            }
        }
        
        $fields = [];
        $values = [];
        $types = '';
        
        foreach ($columnsInfo as $column) {
            $field = $column['Field'];
            
            // Пропускаем системные поля
            if ($column['Extra'] === 'auto_increment' || isTimestampField($column)) {
                continue;
            }
            
            // Обрабатываем только переданные или обязательные поля
            if (isset($_POST[$field]) || ($column['Null'] === 'NO' && $column['Default'] === null)) {
                $fields[] = "`$field`";
                $values[] = isset($_POST[$field]) ? ($_POST[$field] === '' ? null : $_POST[$field]) : null;
                $types .= strpos($column['Type'], 'int') !== false ? 'i' : 's';
            }
        }
        
        try {
            if (!empty($fields)) {
                $sql = "INSERT INTO `$table` (" . implode(',', $fields) . ") VALUES (" . 
                       implode(',', array_fill(0, count($fields), '?')) . ")";
                $stmt = $mysqli->prepare($sql);
                $stmt->bind_param($types, ...$values);
                
                if ($stmt->execute()) {
                    $success = "Запись успешно добавлена";
                } else {
                    throw new Exception($mysqli->sqlstate === '45000' ? $mysqli->error : "Ошибка при добавлении");
                }
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
    elseif (isset($_POST['show_table'])) {
        // Показать таблицу
        $selectedTable = $mysqli->real_escape_string($_POST['table_name']);
        try {
            $result = $mysqli->query("SELECT * FROM `$selectedTable` LIMIT 100");
            if ($result) {
                $tableData = $result->fetch_all(MYSQLI_ASSOC);
                $columns = !empty($tableData) ? array_keys($tableData[0]) : [];
            } else {
                throw new Exception("Ошибка при загрузке таблицы");
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
    elseif (isset($_POST['execute_query'])) {
        // Обработка запросов
        $queryNumber = (int)$_POST['query_number'];
        $currentQuery = $queryNumber;
        
        try {
            // Проверка параметров запроса
            $params = $_POST;
            $validationErrors = validateQueryParams($mysqli, $queryNumber, $params);
            
            if (!empty($validationErrors)) {
                throw new Exception(implode("<br>", $validationErrors));
            }
            
            switch ($queryNumber) {
                // 1. Получить перечень видов изделий отдельной категории и в целом, собираемых указанным цехом, предприятием
                case 1:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $categoryId = isset($_POST['category_id']) ? $mysqli->real_escape_string($_POST['category_id']) : null;
                    
                    $where = [];
                    if ($workshopId) $where[] = "w.id_workshop = '$workshopId'";
                    if ($categoryId) $where[] = "p.category_product_product = '$categoryId'";
                    
                    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                    
                    $sql = "SELECT DISTINCT p.id_product, p.name_type_product, c.name_category_product, w.id_workshop
                            FROM product p
                            JOIN category_product c ON p.category_product_product = c.id_category_product
                            LEFT JOIN particular_product pp ON p.id_product = pp.id_product_pp
                            LEFT JOIN workshop w ON pp.id_workshop_pp = w.id_workshop
                            $whereClause
                            ORDER BY p.name_type_product";
                    break;
                    
                // 2. Получить число и перечень изделий отдельной категории и в целом, собранных указанным цехом, участком, предприятием за период
                case 2:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $sectionId = isset($_POST['section_id']) ? $mysqli->real_escape_string($_POST['section_id']) : null;
                    $categoryId = isset($_POST['category_id']) ? $mysqli->real_escape_string($_POST['category_id']) : null;
                    $startDate = $mysqli->real_escape_string($_POST['start_date']);
                    $endDate = $mysqli->real_escape_string($_POST['end_date']);
                    
                    $where = ["pp.date_start BETWEEN '$startDate' AND '$endDate'"];
                    if ($workshopId) $where[] = "pp.id_workshop_pp = '$workshopId'";
                    if ($sectionId) $where[] = "pp.id_section_pp = '$sectionId'";
                    if ($categoryId) $where[] = "p.category_product_product = '$categoryId'";
                    
                    $sql = "SELECT p.id_product, p.name_type_product, c.name_category_product, 
                                   COUNT(*) as count, w.id_workshop, s.id_section
                            FROM particular_product pp
                            JOIN product p ON pp.id_product_pp = p.id_product
                            JOIN category_product c ON p.category_product_product = c.id_category_product
                            LEFT JOIN workshop w ON pp.id_workshop_pp = w.id_workshop
                            LEFT JOIN section s ON pp.id_section_pp = s.id_section
                            WHERE " . implode(' AND ', $where) . "
                            GROUP BY p.id_product, p.name_type_product, c.name_category_product, w.id_workshop, s.id_section
                            ORDER BY count DESC";
                    break;
                    
                // 3. Данные о кадровом составе цеха, предприятия по категориям персонала
                case 3:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $staffCategory = isset($_POST['staff_category']) ? $mysqli->real_escape_string($_POST['staff_category']) : null;
                    
                    $where = [];
                    if ($workshopId) $where[] = "p.workshop_job = '$workshopId'";
                    if ($staffCategory) $where[] = "pos.staff_category_position = (SELECT id_staff_category FROM staff_category WHERE name_staff_category LIKE '%$staffCategory%')";
                    
                    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                    
                    $sql = "SELECT pos.name_position, COUNT(*) as count, 
                                   GROUP_CONCAT(CONCAT(p.surname, ' ', p.name, ' ', p.patronymic)) as employees
                            FROM person p
                            JOIN position pos ON p.position_person = pos.id_position
                            $whereClause
                            GROUP BY pos.name_position
                            ORDER BY count DESC";
                    break;
                    
                // 4. Число и перечень участков указанного цеха, предприятия и их начальников
                case 4:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    
                    $where = [];
                    if ($workshopId) $where[] = "s.id_workshop_section = '$workshopId'";
                    
                    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                    
                    $sql = "SELECT s.id_section, s.chief_section, 
                                   CONCAT(p.surname, ' ', p.name, ' ', p.patronymic) as chief_name,
                                   w.id_workshop
                            FROM section s
                            LEFT JOIN person p ON s.chief_section = p.id_person
                            JOIN workshop w ON s.id_workshop_section = w.id_workshop
                            $whereClause
                            ORDER BY s.id_section";
                    break;
                    
                // 5. Перечень работ, которые проходит указанное изделие
                case 5:
                    $productId = $mysqli->real_escape_string($_POST['product_id']);
                    
                    $sql = "SELECT w.id_work, w.name_work
                            FROM work w
                            JOIN particular_work pw ON w.id_work = pw.id_work_pw
                            JOIN particular_product pp ON pw.id_particular_product_pw = pp.id_particular_product
                            WHERE pp.id_product_pp = '$productId'
                            ORDER BY w.name_work";
                    break;
                    
                // 6. Состав бригад указанного участка, цеха
                case 6:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $sectionId = isset($_POST['section_id']) ? $mysqli->real_escape_string($_POST['section_id']) : null;
                    
                    $where = [];
                    if ($workshopId) $where[] = "b.id_section_brigade IN (SELECT id_section FROM section WHERE id_workshop_section = '$workshopId')";
                    if ($sectionId) $where[] = "b.id_section_brigade = '$sectionId'";
                    
                    $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                    
                    $sql = "SELECT b.id_brigade, 
                                   CONCAT(p.surname, ' ', p.name, ' ', p.patronymic) as foreman,
                                   GROUP_CONCAT(CONCAT(m.surname, ' ', m.name, ' ', m.patronymic)) as members
                            FROM brigade b
                            LEFT JOIN person p ON b.foreman_brigade = p.id_person
                            LEFT JOIN person m ON m.brigade_job = b.id_brigade
                            $whereClause
                            GROUP BY b.id_brigade, foreman";
                    break;
                    
                // 7. Перечень мастеров указанного участка, цеха
                case 7:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $sectionId = isset($_POST['section_id']) ? $mysqli->real_escape_string($_POST['section_id']) : null;
                    
                    $where = ["pos.name_position LIKE '%Мастер%'"];
                    if ($workshopId) $where[] = "p.workshop_job = '$workshopId'";
                    if ($sectionId) $where[] = "p.section_job = '$sectionId'";
                    
                    $sql = "SELECT p.id_person, p.surname, p.name, p.patronymic, 
                                   pos.name_position, s.id_section, w.id_workshop
                            FROM person p
                            JOIN position pos ON p.position_person = pos.id_position
                            LEFT JOIN section s ON p.section_job = s.id_section
                            LEFT JOIN workshop w ON p.workshop_job = w.id_workshop
                            WHERE " . implode(' AND ', $where) . "
                            ORDER BY p.surname";
                    break;
                    
                // 8. Перечень изделий отдельной категории и в целом, собираемых в настоящий момент
                case 8:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $categoryId = isset($_POST['category_id']) ? $mysqli->real_escape_string($_POST['category_id']) : null;
                    
                    $where = ["pp.date_finish IS NULL"];
                    if ($workshopId) $where[] = "pp.id_workshop_pp = '$workshopId'";
                    if ($categoryId) $where[] = "p.category_product_product = '$categoryId'";
                    
                    $sql = "SELECT p.id_product, p.name_type_product, c.name_category_product, 
                                   w.id_workshop, s.id_section, pp.date_start
                            FROM particular_product pp
                            JOIN product p ON pp.id_product_pp = p.id_product
                            JOIN category_product c ON p.category_product_product = c.id_category_product
                            LEFT JOIN workshop w ON pp.id_workshop_pp = w.id_workshop
                            LEFT JOIN section s ON pp.id_section_pp = s.id_section
                            WHERE " . implode(' AND ', $where) . "
                            ORDER BY pp.date_start";
                    break;
                    
                // 9. Состав бригад, участвующих в сборке указанного изделия
                case 9:
                    $productId = $mysqli->real_escape_string($_POST['product_id']);
                    
                    $sql = "SELECT b.id_brigade, 
                                   CONCAT(p.surname, ' ', p.name, ' ', p.patronymic) as foreman,
                                   GROUP_CONCAT(CONCAT(m.surname, ' ', m.name, ' ', m.patronymic)) as members
                            FROM particular_product pp
                            JOIN brigade b ON pp.id_brigade_pp = b.id_brigade
                            LEFT JOIN person p ON b.foreman_brigade = p.id_person
                            LEFT JOIN person m ON m.brigade_job = b.id_brigade
                            WHERE pp.id_product_pp = '$productId'
                            GROUP BY b.id_brigade, foreman";
                    break;
                    
                // 10. Перечень испытательных лабораторий, участвующих в испытаниях изделия
                case 10:
                    $productId = $mysqli->real_escape_string($_POST['product_id']);
                    
                    $sql = "SELECT DISTINCT l.id_laboratory, l.name_laboratory
                            FROM particular_test pt
                            JOIN type_test tt ON pt.id_type_test_pt = tt.id_type_test
                            JOIN laboratory l ON tt.laboratory_test = l.id_laboratory
                            JOIN particular_product pp ON pt.id_particular_product_pt = pp.id_particular_product
                            WHERE pp.id_product_pp = '$productId'";
                    break;
                    
                // 11. Перечень изделий, проходивших испытание в указанной лаборатории за период
                case 11:
                    $laboratoryId = $mysqli->real_escape_string($_POST['laboratory_id']);
                    $startDate = $mysqli->real_escape_string($_POST['start_date']);
                    $endDate = $mysqli->real_escape_string($_POST['end_date']);
                    if ($startDate && $endDate) {
    // Применяем '00:00:00' для начала первого дня и '23:59:59' для конца последнего дня
                        $startDateTime = $startDate . ' 00:00:00';
                        $endDateTime = $endDate . ' 23:59:59';
                        
                        $where = ["pp.date_finish BETWEEN '$startDateTime' AND '$endDateTime'"];
                    } else {
                        throw new Exception("Пожалуйста, предоставьте правильные даты в формате YYYY-MM-DD.");
                    }
                    $sql = "SELECT p.id_product, p.name_type_product, pt.id_particular_test, 
                                pp.VIN, pt.id_person_pt as tester_id
                            FROM particular_test pt
                            JOIN type_test tt ON pt.id_type_test_pt = tt.id_type_test
                            JOIN particular_product pp ON pt.id_particular_product_pt = pp.id_particular_product
                            JOIN product p ON pp.id_product_pp = p.id_product
                            WHERE tt.laboratory_test = '$laboratoryId' 
                            AND pp.date_start BETWEEN '$startDateTime' AND '$endDateTime'
                            ORDER BY pp.date_start";
                    break;

                // 12. Перечень испытателей, участвующих в испытаниях изделия, категории изделий
                case 12:
                    $productId = isset($_POST['product_id']) ? $mysqli->real_escape_string($_POST['product_id']) : null;
                    $categoryId = isset($_POST['category_id']) ? $mysqli->real_escape_string($_POST['category_id']) : null;
                    $laboratoryId = isset($_POST['laboratory_id']) ? $mysqli->real_escape_string($_POST['laboratory_id']) : null;
                    $startDate = $mysqli->real_escape_string($_POST['start_date']);
                    $endDate = $mysqli->real_escape_string($_POST['end_date']);
                    if ($startDate && $endDate) {
    // Применяем '00:00:00' для начала первого дня и '23:59:59' для конца последнего дня
                        $startDateTime = $startDate . ' 00:00:00';
                        $endDateTime = $endDate . ' 23:59:59';
                        
                        $where = ["pp.date_finish BETWEEN '$startDateTime' AND '$endDateTime'"];
                    } else {
                        throw new Exception("Пожалуйста, предоставьте правильные даты в формате YYYY-MM-DD.");
                    }
                    $where = ["pp.date_start BETWEEN '$startDateTime' AND '$endDateTime'"];
                    if ($productId) $where[] = "pp.id_product_pp = '$productId'";
                    if ($categoryId) $where[] = "p.category_product_product = '$categoryId'";
                    if ($laboratoryId) $where[] = "tt.laboratory_test = '$laboratoryId'";
                    
                    $sql = "SELECT DISTINCT per.id_person, 
                                per.surname,
                                per.name, 
                                per.patronymic, 
                                CONCAT(per.surname, ' ', per.name, ' ', per.patronymic) as full_name,
                                pos.name_position, 
                                l.name_laboratory
                            FROM particular_test pt
                            JOIN person per ON pt.id_person_pt = per.id_person
                            JOIN position pos ON per.position_person = pos.id_position
                            JOIN type_test tt ON pt.id_type_test_pt = tt.id_type_test
                            JOIN laboratory l ON tt.laboratory_test = l.id_laboratory
                            JOIN particular_product pp ON pt.id_particular_product_pt = pp.id_particular_product
                            JOIN product p ON pp.id_product_pp = p.id_product
                            WHERE " . implode(' AND ', $where) . "
                            ORDER BY per.surname";
                    break;

                // 13. Состав оборудования, использовавшегося при испытаниях изделия, категории изделий
                case 13:
                    $productId = isset($_POST['product_id']) ? $mysqli->real_escape_string($_POST['product_id']) : null;
                    $categoryId = isset($_POST['category_id']) ? $mysqli->real_escape_string($_POST['category_id']) : null;
                    $startDate = $mysqli->real_escape_string($_POST['start_date']);
                    $endDate = $mysqli->real_escape_string($_POST['end_date']);
                    if ($startDate && $endDate) {
    // Применяем '00:00:00' для начала первого дня и '23:59:59' для конца последнего дня
                        $startDateTime = $startDate . ' 00:00:00';
                        $endDateTime = $endDate . ' 23:59:59';
                        
                        $where = ["pp.date_finish BETWEEN '$startDateTime' AND '$endDateTime'"];
                    } else {
                        throw new Exception("Пожалуйста, предоставьте правильные даты в формате YYYY-MM-DD.");
                    }
                    $where = ["pp.date_start BETWEEN '$startDateTime' AND '$endDateTime'"];
                    if ($productId) $where[] = "pp.id_product_pp = '$productId'";
                    if ($categoryId) $where[] = "p.category_product_product = '$categoryId'";
                    
                    $sql = "SELECT e.id_equipment, e.name_equipment, 
                                COUNT(*) as usage_count
                            FROM equipment_particular_test ept
                            JOIN equipment e ON ept.id_equipment_ept = e.id_equipment
                            JOIN particular_test pt ON ept.id_particular_test_ept = pt.id_particular_test
                            JOIN particular_product pp ON pt.id_particular_product_pt = pp.id_particular_product
                            JOIN product p ON pp.id_product_pp = p.id_product
                            WHERE " . implode(' AND ', $where) . "
                            GROUP BY e.id_equipment, e.name_equipment
                            ORDER BY usage_count DESC";
                    break;
                    
                // 14. Число и перечень изделий отдельной категории и в целом, собираемых в настоящее время
                case 14:
                    $workshopId = isset($_POST['workshop_id']) ? $mysqli->real_escape_string($_POST['workshop_id']) : null;
                    $sectionId = isset($_POST['section_id']) ? $mysqli->real_escape_string($_POST['section_id']) : null;
                    $categoryId = isset($_POST['category_id']) ? $mysqli->real_escape_string($_POST['category_id']) : null;
                    
                    $where = ["pp.date_finish IS NULL"];
                    if ($workshopId) $where[] = "pp.id_workshop_pp = '$workshopId'";
                    if ($sectionId) $where[] = "pp.id_section_pp = '$sectionId'";
                    if ($categoryId) $where[] = "p.category_product_product = '$categoryId'";
                    
                    $sql = "SELECT p.id_product, p.name_type_product, c.name_category_product, 
                                   COUNT(*) as count, w.id_workshop, s.id_section
                            FROM particular_product pp
                            JOIN product p ON pp.id_product_pp = p.id_product
                            JOIN category_product c ON p.category_product_product = c.id_category_product
                            LEFT JOIN workshop w ON pp.id_workshop_pp = w.id_workshop
                            LEFT JOIN section s ON pp.id_section_pp = s.id_section
                            WHERE " . implode(' AND ', $where) . "
                            GROUP BY p.id_product, p.name_type_product, c.name_category_product, w.id_workshop, s.id_section
                            ORDER BY count DESC";
                    break;
                    
                default:
                    throw new Exception("Неизвестный номер запроса");
            }
            
            $result = $mysqli->query($sql);
            if ($result) {
                $queryResults = $result->fetch_all(MYSQLI_ASSOC);
                if (empty($queryResults)) {
                    throw new Exception("Запрос не вернул результатов. Проверьте параметры запроса.");
                }
            } else {
                throw new Exception("Ошибка выполнения запроса: " . $mysqli->error);
            }
            
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель руководителя</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f9; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1, h2, h3 { color: #333; }
        .form-group { margin-bottom: 20px; }
        select, button, input { padding: 10px; font-size: 16px; border-radius: 4px; border: 1px solid #ddd; }
        select { width: 300px; }
        button { color: white; border: none; cursor: pointer; padding: 10px 20px; margin: 5px; }
        button[type="submit"] { background: #4CAF50; }
        button[type="submit"]:hover { background: #45a049; }
        button[name="logout"] { background: #f44336; }
        button.delete-btn { background: #ff5722; }
        button.add-btn { background: #2196F3; }
        button.query-btn { background: #9C27B0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; position: sticky; top: 0; }
        .error { color: red; margin: 10px 0; padding: 10px; background: #ffeeee; border: 1px solid #ffcccc; border-radius: 4px; }
        .success { color: green; margin: 10px 0; padding: 10px; background: #eeffee; border: 1px solid #ccffcc; border-radius: 4px; }
        .table-container { max-height: 500px; overflow-y: auto; margin-top: 20px; }
        .add-form { margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px; }
        .add-form h3 { margin-top: 0; }
        .add-form .form-group { margin-bottom: 15px; }
        .add-form label { display: inline-block; width: 150px; }
        .query-form { margin-top: 30px; padding: 20px; background: #f0f7ff; border-radius: 8px; }
        .query-form h2 { margin-top: 0; }
        .query-params .form-group { margin-bottom: 15px; }
        .query-params label { display: inline-block; width: 200px; }
        .tab { overflow: hidden; border: 1px solid #ccc; background-color: #f1f1f1; border-radius: 4px; }
        .tab button { background-color: inherit; float: left; border: none; outline: none; cursor: pointer; padding: 14px 16px; transition: 0.3s; color: black; }
        .tab button:hover { background-color: #ddd; }
        .tab button.active { background-color: #4CAF50; color: white; }
        .tabcontent { display: none; padding: 20px 0; border-top: none; }
        .no-results { padding: 20px; background: #fff8e1; border: 1px solid #ffe0b2; border-radius: 4px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Панель руководителя</h1>
        
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <!-- Табы для переключения между режимами -->
        <div class="tab">
            <button class="tablinks <?= $activeTab === 'tables' ? 'active' : '' ?>" onclick="openTab(event, 'tables')">Управление таблицами</button>
            <button class="tablinks <?= $activeTab === 'queries' ? 'active' : '' ?>" onclick="openTab(event, 'queries')">Выполнение запросов</button>
        </div>
        
        <!-- Вкладка управления таблицами -->
        <div id="tables" class="tabcontent" style="display: <?= $activeTab === 'tables' ? 'block' : 'none' ?>;">
            <h2>Управление таблицами</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="table_name">Таблица:</label>
                    <select id="table_name" name="table_name" required>
                        <option value="">-- Выберите таблицу --</option>
                        <?php foreach ($tables as $table): ?>
                            <option value="<?= htmlspecialchars($table) ?>" <?= $selectedTable === $table ? 'selected' : '' ?>>
                                <?= htmlspecialchars($table) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" name="show_table">Показать</button>
            </form>

            <?php if (!empty($tableData)): ?>
                <h3>Таблица: <?= htmlspecialchars($selectedTable) ?></h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <?php foreach ($columns as $col): ?>
                                    <th><?= htmlspecialchars($col) ?></th>
                                <?php endforeach; ?>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tableData as $row): ?>
                                <tr>
                                    <?php foreach ($row as $val): ?>
                                        <td><?= htmlspecialchars($val) ?></td>
                                    <?php endforeach; ?>
                                    <td>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="table_name" value="<?= htmlspecialchars($selectedTable) ?>">
                                            <input type="hidden" name="delete_id" value="<?= htmlspecialchars(reset($row)) ?>">
                                            <button type="submit" class="delete-btn">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="add-form">
                    <h3>Добавить запись</h3>
                    <form method="POST">
                        <input type="hidden" name="table_name" value="<?= htmlspecialchars($selectedTable) ?>">
                        <?php
                        if (!empty($selectedTable)) {
                            $foreignKeys = getForeignKeyInfo($mysqli, $selectedTable);
                            $res = $mysqli->query("SHOW COLUMNS FROM `$selectedTable`");
                            
                            if ($res) {
                                while ($col = $res->fetch_assoc()) {
                                    if ($col['Extra'] === 'auto_increment' || isTimestampField($col)) continue;
                                    
                                    echo '<div class="form-group">';
                                    echo '<label for="'.htmlspecialchars($col['Field']).'">'.htmlspecialchars($col['Field']).':</label>';
                                    
                                    if (isset($foreignKeys[$col['Field']])) {
                                        $ref = $foreignKeys[$col['Field']];
                                        $nameField = findNameField($mysqli, $ref['referenced_table']);
                                        $displayField = $nameField ?: $ref['referenced_column'];
                                        
                                        $refData = $mysqli->query("SELECT {$ref['referenced_column']}, $displayField FROM `{$ref['referenced_table']}`");
                                        
                                        if ($refData && $refData->num_rows > 0) {
                                            echo '<select name="'.htmlspecialchars($col['Field']).'"';
                                            echo ($col['Null'] === 'NO' && $col['Default'] === null) ? ' required' : '';
                                            echo '><option value="">-- Выберите --</option>';
                                            
                                            while ($refRow = $refData->fetch_assoc()) {
                                                $val = $refRow[$ref['referenced_column']];
                                                $display = $nameField ? $refRow[$nameField] : $val;
                                                echo '<option value="'.htmlspecialchars($val).'">'.htmlspecialchars($display).'</option>';
                                            }
                                            echo '</select>';
                                        } else {
                                            echo '<input type="text" name="'.htmlspecialchars($col['Field']).'"';
                                            echo ($col['Null'] === 'NO' && $col['Default'] === null) ? ' required' : '';
                                            echo '>';
                                        }
                                    } else {
                                        echo '<input type="text" name="'.htmlspecialchars($col['Field']).'"';
                                        echo ($col['Null'] === 'NO' && $col['Default'] === null) ? ' required' : '';
                                        echo '>';
                                    }
                                    echo '</div>';
                                }
                            }
                        }
                        ?>
                        <button type="submit" name="add_record" class="add-btn">Добавить</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Вкладка выполнения запросов -->
        <div id="queries" class="tabcontent" style="display: <?= $activeTab === 'queries' ? 'block' : 'none' ?>;">
            <h2>Выполнение запросов</h2>
            
            <div class="query-form">
                <form method="POST">
                    <div class="form-group">
                        <label for="query_number">Выберите запрос:</label>
                        <select id="query_number" name="query_number" required>
                            <option value="">-- Выберите запрос --</option>
                            <?php for ($i = 1; $i <= 14; $i++): ?>
                                <option value="<?= $i ?>" <?= $currentQuery == $i ? 'selected' : '' ?>>
                                    <?= $i ?>. <?= getQueryDescription($i) ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div id="query_params" class="query-params">
                        <?php if (in_array($currentQuery, [1, 2, 3, 4, 6, 7, 8, 14])): ?>
                            <div class="form-group">
                                <label for="workshop_id">ID цеха:</label>
                                <input type="text" id="workshop_id" name="workshop_id" 
                                       value="<?= isset($_POST['workshop_id']) ? htmlspecialchars($_POST['workshop_id']) : '' ?>">
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($currentQuery, [1, 2, 8, 12, 13, 14])): ?>
                            <div class="form-group">
                                <label for="category_id">ID категории изделий:</label>
                                <input type="text" id="category_id" name="category_id" 
                                       value="<?= isset($_POST['category_id']) ? htmlspecialchars($_POST['category_id']) : '' ?>">
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($currentQuery, [2, 6, 7, 8, 14])): ?>
                            <div class="form-group">
                                <label for="section_id">ID участка:</label>
                                <input type="text" id="section_id" name="section_id" 
                                       value="<?= isset($_POST['section_id']) ? htmlspecialchars($_POST['section_id']) : '' ?>">
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($currentQuery, [2, 11, 12, 13])): ?>
                            <div class="form-group">
                                <label for="start_date">Начальная дата:</label>
                                <input type="date" id="start_date" name="start_date" 
                                       value="<?= isset($_POST['start_date']) ? htmlspecialchars($_POST['start_date']) : '' ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">Конечная дата:</label>
                                <input type="date" id="end_date" name="end_date" 
                                       value="<?= isset($_POST['end_date']) ? htmlspecialchars($_POST['end_date']) : '' ?>">
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($currentQuery, [3])): ?>
                            <div class="form-group">
                                <label for="staff_category">Категория персонала:</label>
                                <input type="text" id="staff_category" name="staff_category" 
                                       value="<?= isset($_POST['staff_category']) ? htmlspecialchars($_POST['staff_category']) : '' ?>">
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($currentQuery, [5, 9, 10, 12, 13])): ?>
                            <div class="form-group">
                                <label for="product_id">ID изделия:</label>
                                <input type="text" id="product_id" name="product_id" 
                                       value="<?= isset($_POST['product_id']) ? htmlspecialchars($_POST['product_id']) : '' ?>">
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($currentQuery, [11, 12, 13])): ?>
                            <div class="form-group">
                                <label for="laboratory_id">ID лаборатории:</label>
                                <input type="text" id="laboratory_id" name="laboratory_id" 
                                       value="<?= isset($_POST['laboratory_id']) ? htmlspecialchars($_POST['laboratory_id']) : '' ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" name="execute_query" class="query-btn">Выполнить запрос</button>
                </form>
            </div>
            
            <?php if (isset($_POST['execute_query'])): ?>
                <div class="results">
                    <h3>Результаты запроса <?= $currentQuery ?>: <?= getQueryDescription($currentQuery) ?></h3>
                    <?php if (!empty($queryResults)): ?>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <?php foreach (array_keys($queryResults[0]) as $column): ?>
                                            <th><?= htmlspecialchars($column) ?></th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($queryResults as $row): ?>
                                        <tr>
                                            <?php foreach ($row as $value): ?>
                                                <td><?= htmlspecialchars($value) ?></td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="no-results">
                            Запрос не вернул результатов. Проверьте параметры запроса.
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <form method="POST" style="margin-top:20px;">
            <button type="submit" name="logout">Выход</button>
        </form>
    </div>

    <script>
        // Функция для переключения вкладок
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        // JavaScript для динамического отображения полей ввода запросов
        document.getElementById('query_number').addEventListener('change', function() {
            const queryNumber = parseInt(this.value);
            const paramsContainer = document.getElementById('query_params');
            paramsContainer.innerHTML = '';

            // Добавляем поля в зависимости от выбранного запроса
            if ([1, 2, 3, 4, 6, 7, 8, 14].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="workshop_id">ID цеха:</label>
                        <input type="text" id="workshop_id" name="workshop_id">
                    </div>
                `;
            }
            
            if ([1, 2, 8, 12, 13, 14].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="category_id">ID категории изделий:</label>
                        <input type="text" id="category_id" name="category_id">
                    </div>
                `;
            }
            
            if ([2, 6, 7, 8, 14].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="section_id">ID участка:</label>
                        <input type="text" id="section_id" name="section_id">
                    </div>
                `;
            }
            
            if ([2, 11, 12, 13].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="start_date">Начальная дата:</label>
                        <input type="date" id="start_date" name="start_date">
                    </div>
                    <div class="form-group">
                        <label for="end_date">Конечная дата:</label>
                        <input type="date" id="end_date" name="end_date">
                    </div>
                `;
            }
            
            if ([3].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="staff_category">Категория персонала:</label>
                        <input type="text" id="staff_category" name="staff_category">
                    </div>
                `;
            }
            
            if ([5, 9, 10, 12, 13].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="product_id">ID изделия:</label>
                        <input type="text" id="product_id" name="product_id">
                    </div>
                `;
            }
            
            if ([11, 12, 13].includes(queryNumber)) {
                paramsContainer.innerHTML += `
                    <div class="form-group">
                        <label for="laboratory_id">ID лаборатории:</label>
                        <input type="text" id="laboratory_id" name="laboratory_id">
                    </div>
                `;
            }
        });
    </script>
</body>
</html>

<?php
function getQueryDescription($number) {
    $descriptions = [
        1 => "Перечень видов изделий отдельной категории и в целом, собираемых указанным цехом, предприятием",
        2 => "Число и перечень изделий отдельной категории и в целом, собранных указанным цехом, участком, предприятием за период",
        3 => "Данные о кадровом составе цеха, предприятия по категориям персонала",
        4 => "Число и перечень участков указанного цеха, предприятия и их начальников",
        5 => "Перечень работ, которые проходит указанное изделие",
        6 => "Состав бригад указанного участка, цеха",
        7 => "Перечень мастеров указанного участка, цеха",
        8 => "Перечень изделий отдельной категории и в целом, собираемых в настоящий момент",
        9 => "Состав бригад, участвующих в сборке указанного изделия",
        10 => "Перечень испытательных лабораторий, участвующих в испытаниях изделия",
        11 => "Перечень изделий, проходивших испытание в указанной лаборатории за период",
        12 => "Перечень испытателей, участвующих в испытаниях изделия, категории изделий",
        13 => "Состав оборудования, использовавшегося при испытаниях изделия, категории изделий",
        14 => "Число и перечень изделий отдельной категории и в целом, собираемых в настоящее время"
    ];
    return $descriptions[$number] ?? "Неизвестный запрос";
}
?>