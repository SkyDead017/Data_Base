-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: MySQL-8.0
-- Время создания: Май 15 2025 г., 10:48
-- Версия сервера: 8.0.35
-- Версия PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `AutomotiveManufacturingCompany`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_brigade_validity` (IN `p_brigade_id` INT, IN `p_section_id` INT, OUT `p_exists` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    SELECT COUNT(*) INTO p_exists FROM brigade WHERE id_brigade = p_brigade_id;
    
    IF p_exists = 0 THEN
        SET p_error_message = 'ОШИБКА: Такой бригады не существует!';
    ELSEIF p_section_id IS NOT NULL AND 
           p_section_id != (SELECT id_section_brigade FROM brigade WHERE id_brigade = p_brigade_id) THEN
        SET p_error_message = 'ОШИБКА: В указанном участке нет такой бригады!';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_chief_section` (IN `p_person_id` INT, IN `p_section_id` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    DECLARE current_chief INT;
    
    SELECT chief_section INTO current_chief 
    FROM section 
    WHERE id_section = p_section_id;
    
    IF current_chief IS NOT NULL THEN
        SET p_error_message = 'ОШИБКА: У этого участка уже есть начальник!';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_chief_workshop` (IN `p_person_id` INT, IN `p_workshop_id` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    DECLARE current_chief INT;
    
    SELECT chief_workshop INTO current_chief 
    FROM workshop 
    WHERE id_workshop = p_workshop_id;
    
    IF current_chief IS NOT NULL THEN
        SET p_error_message = 'ОШИБКА: У этого цеха уже есть начальник!';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_education_position_match` (IN `p_education` VARCHAR(50), IN `p_position_id` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    DECLARE staff_category_name VARCHAR(50);
    
    SELECT sc.name_staff_category INTO staff_category_name
    FROM staff_category sc
    JOIN `position` p ON sc.id_staff_category = p.staff_category_position
    WHERE p.id_position = p_position_id;
    
    IF p_education = 'Высшее' AND staff_category_name = 'Рабочий персонал' THEN
        SET p_error_message = 'ОШИБКА: Человек с высшим образованием не может занимать должность с категорией "Рабочий персонал" !';
    ELSEIF p_education = 'Среднее специальное' AND staff_category_name = 'Инженерно-технический персонал' THEN
        SET p_error_message = 'ОШИБКА: Человек со средним специальным образованием не может занимать должность с категорией "Инженерно-технический персонал" !';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_foreman_brigade` (IN `p_person_id` INT, IN `p_brigade_id` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    DECLARE current_foreman INT;
    
    SELECT foreman_brigade INTO current_foreman 
    FROM brigade 
    WHERE id_brigade = p_brigade_id;
    
    IF current_foreman IS NOT NULL THEN
        SET p_error_message = 'ОШИБКА: У этой бригады уже есть бригадир!';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_section_validity` (IN `p_section_id` INT, IN `p_workshop_id` INT, OUT `p_exists` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    SELECT COUNT(*) INTO p_exists FROM section WHERE id_section = p_section_id;
    
    IF p_exists = 0 THEN
        SET p_error_message = 'ОШИБКА: Такого участка не существует!';
    ELSEIF p_workshop_id IS NOT NULL AND 
           p_workshop_id != (SELECT id_workshop_section FROM section WHERE id_section = p_section_id) THEN
        SET p_error_message = 'ОШИБКА: В указанном цехе нет такого участка!';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

CREATE DEFINER=`developer`@`localhost` PROCEDURE `check_workshop_validity` (IN `p_workshop_id` INT, OUT `p_exists` INT, OUT `p_error_message` VARCHAR(255))   BEGIN
    SELECT COUNT(*) INTO p_exists FROM workshop WHERE id_workshop = p_workshop_id;
    
    IF p_exists = 0 THEN
        SET p_error_message = 'ОШИБКА: Такого цеха не существует!';
    ELSE
        SET p_error_message = NULL;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `brigade`
--

CREATE TABLE `brigade` (
  `id_brigade` int NOT NULL,
  `id_section_brigade` int NOT NULL,
  `foreman_brigade` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `brigade`
--

INSERT INTO `brigade` (`id_brigade`, `id_section_brigade`, `foreman_brigade`) VALUES
(1, 1, 7),
(2, 1, 8),
(3, 2, 9),
(4, 2, 10),
(5, 3, 11),
(6, 3, 12),
(7, 4, 13),
(8, 4, 14);

-- --------------------------------------------------------

--
-- Структура таблицы `category_product`
--

CREATE TABLE `category_product` (
  `id_category_product` int NOT NULL,
  `name_category_product` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `category_product`
--

INSERT INTO `category_product` (`id_category_product`, `name_category_product`) VALUES
(1, 'Легковой автомобиль'),
(2, 'Грузовой автомобиль'),
(3, 'Автобус'),
(4, 'Дорожно-строительная машина'),
(5, 'Мотоцикл');

-- --------------------------------------------------------

--
-- Структура таблицы `characteristic_person`
--

CREATE TABLE `characteristic_person` (
  `id_characteristic_person` int NOT NULL,
  `name_characteristic_person` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `characteristic_person`
--

INSERT INTO `characteristic_person` (`id_characteristic_person`, `name_characteristic_person`) VALUES
(1, 'Опыт работы (лет)'),
(2, 'Уровень квалификации (разряд)'),
(3, 'Знание английского языка (A1-C2)'),
(4, 'Готовность к сверхурочным'),
(5, 'Наличие допуска к спецтехнике'),
(6, 'Аллергии (да/нет)'),
(7, 'Водительские права (категория)'),
(8, 'Навыки сварки (уровень 1-5)'),
(9, 'Знание CAD/CAM систем'),
(10, 'Готовность к командировкам'),
(11, 'Медицинская книжка (да/нет)'),
(12, 'Стрессоустойчивость (уровень 1-5)'),
(13, 'Лидерские качества'),
(14, 'Навыки работы с ЧПУ'),
(15, 'Знание норм безопасности');

-- --------------------------------------------------------

--
-- Структура таблицы `characteristic_product`
--

CREATE TABLE `characteristic_product` (
  `id_characteristic_product` int NOT NULL,
  `name_characteristic_product` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `characteristic_product`
--

INSERT INTO `characteristic_product` (`id_characteristic_product`, `name_characteristic_product`) VALUES
(1, 'Максимальная скорость (км/ч)'),
(2, 'Разгон 0-100 км/ч (сек)'),
(3, 'Расход топлива (л/100 км)'),
(4, 'Грузоподъемность (кг)'),
(5, 'Мощность двигателя (л.с.)'),
(6, 'Крутящий момент (Нм)'),
(7, 'Объем багажника (л)'),
(8, 'Клиренс (мм)'),
(9, 'Уровень шума (дБ)'),
(10, 'Срок службы (лет)'),
(11, 'Вес (кг)'),
(12, 'Количество мест'),
(13, 'Эмиссия CO2 (г/км)'),
(14, 'Тормозной путь (м)'),
(15, 'Тип привода (FWD/RWD/AWD)');

-- --------------------------------------------------------

--
-- Структура таблицы `equipment`
--

CREATE TABLE `equipment` (
  `id_equipment` int NOT NULL,
  `name_equipment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `equipment`
--

INSERT INTO `equipment` (`id_equipment`, `name_equipment`) VALUES
(1, 'Имитатор дождя'),
(2, 'Многокомпонентный датчик нагрузки'),
(3, 'Шумомер'),
(4, 'Топливный стенд'),
(5, 'Газоанализатор'),
(6, 'Высокоскоростная камера'),
(7, 'Аэродинамическая труба с системой дыма'),
(8, 'Сварочный конвектор');

-- --------------------------------------------------------

--
-- Структура таблицы `equipment_particular_test`
--

CREATE TABLE `equipment_particular_test` (
  `id_particular_test_ept` int NOT NULL,
  `id_equipment_ept` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `equipment_particular_test`
--

INSERT INTO `equipment_particular_test` (`id_particular_test_ept`, `id_equipment_ept`) VALUES
(5, 1),
(1, 2),
(2, 2),
(7, 2),
(4, 3),
(3, 4),
(3, 5),
(1, 6),
(7, 6),
(6, 7);

-- --------------------------------------------------------

--
-- Структура таблицы `laboratory`
--

CREATE TABLE `laboratory` (
  `id_laboratory` int NOT NULL,
  `name_laboratory` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `laboratory`
--

INSERT INTO `laboratory` (`id_laboratory`, `name_laboratory`) VALUES
(1, 'Динамические и нагрузочные испытания'),
(2, 'Климатические и экстремальные испытания'),
(3, 'Энергоэффективность и экологические испытания');

-- --------------------------------------------------------

--
-- Структура таблицы `particular_product`
--

CREATE TABLE `particular_product` (
  `id_particular_product` int NOT NULL,
  `id_workshop_pp` int NOT NULL,
  `id_section_pp` int NOT NULL,
  `id_brigade_pp` int NOT NULL,
  `id_product_pp` int NOT NULL,
  `VIN` varchar(17) NOT NULL,
  `date_start` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_finish` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `particular_product`
--

INSERT INTO `particular_product` (`id_particular_product`, `id_workshop_pp`, `id_section_pp`, `id_brigade_pp`, `id_product_pp`, `VIN`, `date_start`, `date_finish`) VALUES
(1, 1, 1, 1, 1, 'XTA210999G0123456', '2023-01-10 08:00:00', '2023-01-25 16:30:00'),
(2, 1, 1, 1, 1, 'XTA210999G0123457', '2023-01-12 08:00:00', '2023-01-27 15:45:00'),
(3, 1, 1, 2, 2, 'XTA211000H0123458', '2023-02-01 08:00:00', '2023-02-15 17:20:00'),
(4, 1, 2, 3, 5, 'XTA330001J0123459', '2023-02-10 08:00:00', '2023-03-01 14:10:00'),
(5, 1, 2, 4, 6, 'XTA330002K0123460', '2025-02-15 08:00:00', '2025-06-05 16:45:00'),
(6, 2, 3, 5, 8, 'XTA550003L0123461', '2023-03-01 08:00:00', '2023-03-20 15:30:00'),
(7, 2, 3, 6, 9, 'XTA550004M0123462', '2023-03-05 08:00:00', '2023-03-25 17:00:00'),
(8, 2, 4, 7, 12, 'XTA770005N0123463', '2023-04-01 08:00:00', '2026-04-15 16:15:00'),
(9, 2, 4, 8, 13, 'XTA770006P0123464', '2023-04-10 08:00:00', '2023-04-25 14:45:00'),
(10, 1, 1, 1, 16, 'XTA880007R0123465', '2023-05-01 08:00:00', '2023-05-10 13:20:00');

--
-- Триггеры `particular_product`
--
DELIMITER $$
CREATE TRIGGER `trg_particular_product` BEFORE INSERT ON `particular_product` FOR EACH ROW BEGIN
	DECLARE workshop_exists INT;
    DECLARE section_exists INT;
    DECLARE brigade_exists INT;
    SELECT COUNT(*) INTO section_exists 
    FROM section 
    WHERE id_section = NEW.id_section_pp;
    SELECT COUNT(*) INTO workshop_exists 
  	FROM workshop 
  	WHERE id_workshop = NEW.id_workshop_pp;
    SELECT COUNT(*) INTO brigade_exists 
	FROM brigade 
	WHERE id_brigade = NEW.id_brigade_pp;
    if workshop_exists=0 THEN
		SIGNAL SQLSTATE '45000'
      	SET MESSAGE_TEXT = 'ОШИБКА: Такого цеха не существует!';
  	END IF;
 	if section_exists=0 THEN
      	SIGNAL SQLSTATE '45000'
      	SET MESSAGE_TEXT = 'ОШИБКА: Такого участка не существует!';
   	END IF;
   	if brigade_exists=0 THEN
  		SIGNAL SQLSTATE '45000'
   		SET MESSAGE_TEXT = 'ОШИБКА: Такой бригады не существует!';
 	END IF;
    
	if NEW.id_workshop_pp != (SELECT id_workshop_section FROM section WHERE id_section=NEW.id_section_pp) THEN 		SIGNAL SQLSTATE '45000'
  	SET MESSAGE_TEXT = 'ОШИБКА: В указанном цехе нет такого участка!';
	END IF;
    if NEW.id_section_pp != (SELECT id_section_brigade FROM brigade WHERE id_brigade=NEW.id_brigade_pp) THEN 		SIGNAL SQLSTATE '45000'
  	SET MESSAGE_TEXT = 'ОШИБКА: В указанном участке нет такой бригады!';
	END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_vin_length` BEFORE INSERT ON `particular_product` FOR EACH ROW BEGIN
    IF CHAR_LENGTH(NEW.`VIN`) != 17 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Длина VIN должна быть 17 символов';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `particular_test`
--

CREATE TABLE `particular_test` (
  `id_particular_test` int NOT NULL,
  `id_person_pt` int NOT NULL,
  `id_type_test_pt` int NOT NULL,
  `id_particular_product_pt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `particular_test`
--

INSERT INTO `particular_test` (`id_particular_test`, `id_person_pt`, `id_type_test_pt`, `id_particular_product_pt`) VALUES
(1, 15, 1, 1),
(2, 16, 2, 1),
(3, 17, 5, 4),
(4, 18, 6, 4),
(5, 15, 3, 6),
(6, 16, 4, 6),
(7, 17, 1, 10);

--
-- Триггеры `particular_test`
--
DELIMITER $$
CREATE TRIGGER `trg_particular_test_tester` BEFORE INSERT ON `particular_test` FOR EACH ROW BEGIN
	DECLARE position_tester INT;
    DECLARE current_tester INT;
	SELECT id_position INTO position_tester 
    FROM `position` 
    WHERE name_position = 'Испытатель';
    SELECT position_person INTO current_tester
    FROM person
    WHERE NEW.id_person_pt = id_person;
    IF current_tester!=position_tester THEN
    	SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Человек, проводящий испытание должен занимать должность "Испытатель"!';
  	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `particular_work`
--

CREATE TABLE `particular_work` (
  `id_work_pw` int NOT NULL,
  `id_particular_product_pw` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `particular_work`
--

INSERT INTO `particular_work` (`id_work_pw`, `id_particular_product_pw`) VALUES
(1, 1),
(2, 1),
(3, 1),
(1, 3),
(4, 3),
(5, 3),
(1, 4),
(4, 4),
(1, 6),
(3, 6),
(2, 10),
(4, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `person`
--

CREATE TABLE `person` (
  `id_person` int NOT NULL,
  `position_person` int NOT NULL,
  `surname` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `patronymic` varchar(50) NOT NULL,
  `gender` enum('женщина','мужчина') NOT NULL,
  `birthday` date NOT NULL,
  `education` enum('Среднее специальное','Высшее') NOT NULL,
  `date_start` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `workshop_job` int DEFAULT NULL,
  `section_job` int DEFAULT NULL,
  `brigade_job` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `person`
--

INSERT INTO `person` (`id_person`, `position_person`, `surname`, `name`, `patronymic`, `gender`, `birthday`, `education`, `date_start`, `workshop_job`, `section_job`, `brigade_job`) VALUES
(1, 1, 'Ковалевский', 'Арсений', 'Леонидович', 'мужчина', '1975-08-12', 'Высшее', '2010-05-18 00:00:00', 1, NULL, NULL),
(2, 1, 'Зайцева', 'Ольга', 'Витальевна', 'женщина', '1978-03-25', 'Высшее', '2012-09-14 00:00:00', 2, NULL, NULL),
(3, 2, 'Щербаков', 'Денис', 'Геннадьевич', 'мужчина', '1982-11-08', 'Высшее', '2015-07-22 00:00:00', 1, 1, NULL),
(4, 2, 'Мельникова', 'Анастасия', 'Игоревна', 'женщина', '1985-06-19', 'Высшее', '2016-03-15 00:00:00', 1, 2, NULL),
(5, 2, 'Белов', 'Станислав', 'Аркадьевич', 'мужчина', '1980-09-30', 'Высшее', '2014-11-05 00:00:00', 2, 3, NULL),
(6, 2, 'Григорьева', 'Евгения', 'Олеговна', 'женщина', '1983-04-17', 'Высшее', '2015-08-20 00:00:00', 2, 4, NULL),
(7, 8, 'Терентьев', 'Роман', 'Борисович', 'мужчина', '1988-07-14', 'Среднее специальное', '2017-04-12 00:00:00', 1, 1, 1),
(8, 8, 'Савельева', 'Инна', 'Васильевна', 'женщина', '1989-12-03', 'Среднее специальное', '2018-01-25 00:00:00', 1, 1, 2),
(9, 8, 'Фролов', 'Глеб', 'Анатольевич', 'мужчина', '1990-05-28', 'Среднее специальное', '2018-09-18 00:00:00', 1, 2, 3),
(10, 8, 'Королева', 'Вероника', 'Сергеевна', 'женщина', '1987-10-11', 'Среднее специальное', '2016-11-30 00:00:00', 1, 2, 4),
(11, 8, 'Давыдов', 'Артур', 'Эдуардович', 'мужчина', '1989-02-22', 'Среднее специальное', '2017-08-15 00:00:00', 2, 3, 5),
(12, 8, 'Орлова', 'Диана', 'Романовна', 'женщина', '1991-08-09', 'Среднее специальное', '2019-05-22 00:00:00', 2, 3, 6),
(13, 8, 'Семенов', 'Вадим', 'Ильич', 'мужчина', '1988-04-05', 'Среднее специальное', '2017-12-10 00:00:00', 2, 4, 7),
(14, 8, 'Кузьмина', 'Элина', 'Дмитриевна', 'женщина', '1990-11-17', 'Среднее специальное', '2018-07-08 00:00:00', 2, 4, 8),
(15, 9, 'Лазарев', 'Максим', 'Григорьевич', 'мужчина', '1985-09-23', 'Высшее', '2013-06-14 00:00:00', NULL, NULL, NULL),
(16, 9, 'Беляева', 'Ксения', 'Андреевна', 'женщина', '1987-01-15', 'Высшее', '2014-10-28 00:00:00', NULL, NULL, NULL),
(17, 9, 'Гордеев', 'Павел', 'Викторович', 'мужчина', '1986-07-30', 'Высшее', '2014-03-19 00:00:00', NULL, NULL, NULL),
(18, 9, 'Соколова', 'Арина', 'Ивановна', 'женщина', '1988-12-08', 'Высшее', '2015-09-05 00:00:00', NULL, NULL, NULL),
(19, 3, 'Тихонов', 'Ярослав', 'Федорович', 'мужчина', '1983-04-12', 'Высшее', '2015-08-22 00:00:00', 1, 1, NULL),
(20, 3, 'Власова', 'Алиса', 'Константиновна', 'женщина', '1986-11-25', 'Высшее', '2017-02-14 00:00:00', 1, 1, NULL),
(21, 3, 'Крылов', 'Артем', 'Степанович', 'мужчина', '1984-08-19', 'Высшее', '2016-05-30 00:00:00', 1, 1, NULL),
(22, 3, 'Маркова', 'Виктория', 'Алексеевна', 'женщина', '1985-02-28', 'Высшее', '2016-11-08 00:00:00', 1, 2, NULL),
(23, 3, 'Суханов', 'Илья', 'Русланович', 'мужчина', '1983-10-15', 'Высшее', '2015-09-17 00:00:00', 1, 2, NULL),
(24, 3, 'Зимина', 'Елена', 'Валерьевна', 'женщина', '1987-07-03', 'Высшее', '2017-04-25 00:00:00', 1, 2, NULL),
(25, 3, 'Баранов', 'Данила', 'Геннадьевич', 'мужчина', '1982-12-22', 'Высшее', '2014-10-12 00:00:00', 2, 3, NULL),
(26, 3, 'Гаврилова', 'София', 'Артемовна', 'женщина', '1986-05-14', 'Высшее', '2017-01-20 00:00:00', 2, 3, NULL),
(27, 3, 'Ермаков', 'Руслан', 'Олегович', 'мужчина', '1984-09-08', 'Высшее', '2015-12-05 00:00:00', 2, 3, NULL),
(28, 3, 'Ковалев', 'Мирон', 'Анатольевич', 'мужчина', '1983-06-30', 'Высшее', '2015-07-18 00:00:00', 2, 4, NULL),
(29, 3, 'Полякова', 'Ангелина', 'Владиславовна', 'женщина', '1988-03-17', 'Высшее', '2018-02-22 00:00:00', 2, 4, NULL),
(30, 3, 'Широков', 'Герман', 'Борисович', 'мужчина', '1985-01-25', 'Высшее', '2016-09-14 00:00:00', 2, 4, NULL),
(31, 4, 'Медведев', 'Тимур', 'Ростиславович', 'мужчина', '1992-08-14', 'Среднее специальное', '2018-05-20 00:00:00', 1, 1, 1),
(32, 5, 'Абрамова', 'Яна', 'Игоревна', 'женщина', '1993-04-03', 'Среднее специальное', '2019-02-15 00:00:00', 1, 1, 1),
(33, 6, 'Носков', 'Кирилл', 'Артурович', 'мужчина', '1991-11-27', 'Среднее специальное', '2017-10-08 00:00:00', 1, 1, 1),
(34, 7, 'Родионова', 'Алиса', 'Денисовна', 'женщина', '1994-07-19', 'Среднее специальное', '2020-03-12 00:00:00', 1, 1, 1),
(35, 4, 'Горелов', 'Арсений', 'Вадимович', 'мужчина', '1990-12-08', 'Среднее специальное', '2016-09-25 00:00:00', 1, 1, 2),
(36, 5, 'Сазонова', 'Эвелина', 'Анатольевна', 'женщина', '1992-05-22', 'Среднее специальное', '2018-04-18 00:00:00', 1, 1, 2),
(37, 6, 'Белоусов', 'Матвей', 'Сергеевич', 'мужчина', '1993-02-14', 'Среднее специальное', '2019-01-10 00:00:00', 1, 1, 2),
(38, 7, 'Куликова', 'Валерия', 'Олеговна', 'женщина', '1991-09-30', 'Среднее специальное', '2017-08-22 00:00:00', 1, 1, 2),
(39, 4, 'Фомичев', 'Демид', 'Александрович', 'мужчина', '1993-06-25', 'Среднее специальное', '2019-05-15 00:00:00', 1, 2, 3),
(40, 5, 'Ларина', 'Амелия', 'Витальевна', 'женщина', '1994-03-18', 'Среднее специальное', '2020-02-08 00:00:00', 1, 2, 3),
(41, 6, 'Сорокин', 'Платон', 'Иванович', 'мужчина', '1992-10-11', 'Среднее специальное', '2018-07-30 00:00:00', 1, 2, 3),
(42, 7, 'Маслова', 'Арина', 'Евгеньевна', 'женщина', '1991-07-05', 'Среднее специальное', '2017-11-14 00:00:00', 1, 2, 3),
(43, 4, 'Кудрявцев', 'Ян', 'Артемович', 'мужчина', '1990-04-19', 'Среднее специальное', '2016-10-22 00:00:00', 1, 2, 4),
(44, 5, 'Бирюкова', 'Кристина', 'Романовна', 'женщина', '1992-01-28', 'Среднее специальное', '2018-03-17 00:00:00', 1, 2, 4),
(45, 6, 'Гусев', 'Артемий', 'Дмитриевич', 'мужчина', '1993-08-12', 'Среднее специальное', '2019-06-25 00:00:00', 1, 2, 4),
(46, 7, 'Антонова', 'Милана', 'Андреевна', 'женщина', '1991-05-07', 'Среднее специальное', '2017-09-18 00:00:00', 1, 2, 4),
(47, 4, 'Шестаков', 'Марк', 'Глебович', 'мужчина', '1992-09-14', 'Среднее специальное', '2018-08-10 00:00:00', 2, 3, 5),
(48, 5, 'Громова', 'Алисия', 'Тимофеевна', 'женщина', '1994-02-27', 'Среднее специальное', '2020-01-22 00:00:00', 2, 3, 5),
(49, 6, 'Калинин', 'Родион', 'Валентинович', 'мужчина', '1991-12-05', 'Среднее специальное', '2017-06-15 00:00:00', 2, 3, 5),
(50, 7, 'Воронцова', 'Есения', 'Аркадьевна', 'женщина', '1993-07-30', 'Среднее специальное', '2019-04-08 00:00:00', 2, 3, 5),
(51, 4, 'Логинов', 'Всеволод', 'Семенович', 'мужчина', '1990-11-18', 'Среднее специальное', '2016-12-20 00:00:00', 2, 3, 6),
(52, 5, 'Силина', 'Диана', 'Геннадьевна', 'женщина', '1992-06-22', 'Среднее специальное', '2018-05-14 00:00:00', 2, 3, 6),
(53, 6, 'Куприянов', 'Савва', 'Романович', 'мужчина', '1993-03-15', 'Среднее специальное', '2019-02-05 00:00:00', 2, 3, 6),
(54, 7, 'Зайцева', 'Камилла', 'Владимировна', 'женщина', '1991-10-08', 'Среднее специальное', '2017-09-28 00:00:00', 2, 3, 6),
(55, 4, 'Степанов', 'Прохор', 'Анатольевич', 'мужчина', '1992-05-17', 'Среднее специальное', '2018-04-12 00:00:00', 2, 4, 7),
(56, 5, 'Козлова', 'Элина', 'Сергеевна', 'женщина', '1994-01-30', 'Среднее специальное', '2020-03-25 00:00:00', 2, 4, 7),
(57, 6, 'Никитин', 'Гордей', 'Игоревич', 'мужчина', '1991-08-23', 'Среднее специальное', '2017-11-15 00:00:00', 2, 4, 7),
(58, 7, 'Орехова', 'Виолетта', 'Денисовна', 'женщина', '1993-04-14', 'Среднее специальное', '2019-01-08 00:00:00', 2, 4, 7),
(59, 4, 'Макаров', 'Святослав', 'Васильевич', 'мужчина', '1990-07-29', 'Среднее специальное', '2016-10-18 00:00:00', 2, 4, 8),
(60, 5, 'Исакова', 'Амина', 'Руслановна', 'женщина', '1992-02-11', 'Среднее специальное', '2018-03-05 00:00:00', 2, 4, 8),
(61, 6, 'Большаков', 'Мирослав', 'Алексеевич', 'мужчина', '1993-09-04', 'Среднее специальное', '2019-06-20 00:00:00', 2, 4, 8),
(62, 7, 'Лаптева', 'Арина', 'Артемовна', 'женщина', '1991-12-22', 'Среднее специальное', '2017-08-14 00:00:00', 2, 4, 8),
(64, 6, 'Ившин', 'Максим', 'Сергеевич', 'мужчина', '2005-03-07', 'Среднее специальное', '2025-05-14 11:31:01', 1, 1, 1);

--
-- Триггеры `person`
--
DELIMITER $$
CREATE TRIGGER `trg_insert_person` AFTER INSERT ON `person` FOR EACH ROW BEGIN
	DECLARE current_name_position_person VARCHAR(50);
    SELECT name_position INTO current_name_position_person 
    FROM `position` 
    WHERE id_position = NEW.position_person;
	IF current_name_position_person = 'Начальник цеха' THEN
    	UPDATE workshop
        SET chief_workshop=NEW.id_person
        WHERE id_workshop=NEW.workshop_job;
        
    ELSEIF current_name_position_person = 'Начальник участка' THEN
    	UPDATE section
        SET chief_section=NEW.id_person
        WHERE id_section=NEW.section_job;
        
    ELSEIF current_name_position_person = 'Бригадир' THEN
    	UPDATE brigade
        SET foreman_brigade=NEW.id_person
        WHERE id_brigade=NEW.brigade_job;
    END IF;
    INSERT INTO `person_movement` (id_person_movement, action, new_position, new_workshop, new_section, new_brigade, movement_date) 
   	VALUES (NEW.id_person, CONCAT('Принят на работу в должности ', current_name_position_person), NEW.position_person, NEW.workshop_job, NEW.section_job, NEW.brigade_job, CURRENT_DATE());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_person_delete` BEFORE DELETE ON `person` FOR EACH ROW BEGIN
	SET FOREIGN_KEY_CHECKS = 0;
    DELETE FROM person_movement WHERE id_person_movement = OLD.id_person;
    
    INSERT INTO person_movement (id_person_movement, action, old_position, new_position, old_workshop, new_workshop, old_section, new_section, old_brigade, new_brigade, movement_date) 
    VALUES (OLD.id_person, 'Уволен', OLD.position_person, NULL, OLD.workshop_job, NULL, OLD.section_job, NULL, OLD.brigade_job, NULL, CURRENT_DATE());
    UPDATE workshop SET chief_workshop = NULL WHERE chief_workshop = OLD.id_person;
    UPDATE section SET chief_section = NULL WHERE chief_section = OLD.id_person;
    UPDATE brigade SET foreman_brigade = NULL WHERE foreman_brigade = OLD.id_person;
    SET FOREIGN_KEY_CHECKS = 1;
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_person_update` AFTER UPDATE ON `person` FOR EACH ROW BEGIN
    DECLARE has_changes BOOLEAN DEFAULT FALSE;
    
    -- Проверяем, изменились ли значимые поля
    IF (NEW.position_person != OLD.position_person OR
        NEW.workshop_job != OLD.workshop_job OR
        NEW.section_job != OLD.section_job OR
        NEW.brigade_job != OLD.brigade_job) THEN
        SET has_changes = TRUE;
    END IF;
    
    -- Если есть изменения - вставляем запись в лог
    IF has_changes THEN
        INSERT INTO person_movement (id_person_movement, action, old_position, new_position, old_workshop, new_workshop, old_section, new_section, old_brigade, new_brigade, movement_date)
        VALUES (NEW.id_person, 'Изменение данных', OLD.position_person, NEW.position_person, OLD.workshop_job, NEW.workshop_job, OLD.section_job, NEW.section_job, OLD.brigade_job, NEW.brigade_job, CURRENT_DATE());
        
        -- Обновляем ссылки на руководителей, если изменилась должность
        IF NEW.position_person != OLD.position_person THEN
            -- Если был начальником цеха - очищаем ссылку
            IF OLD.position_person = (SELECT id_position FROM `position` WHERE name_position = 'Начальник цеха') THEN
                UPDATE workshop SET chief_workshop = NULL WHERE chief_workshop = OLD.id_person;
            END IF;
            
            -- Если был начальником участка - очищаем ссылку
            IF OLD.position_person = (SELECT id_position FROM `position` WHERE name_position = 'Начальник участка') THEN
                UPDATE section SET chief_section = NULL WHERE chief_section = OLD.id_person;
            END IF;
            
            -- Если был бригадиром - очищаем ссылку
            IF OLD.position_person = (SELECT id_position FROM `position` WHERE name_position = 'Бригадир') THEN
                UPDATE brigade SET foreman_brigade = NULL WHERE foreman_brigade = OLD.id_person;
            END IF;
            
            -- Если стал начальником цеха - устанавливаем ссылку
            IF NEW.position_person = (SELECT id_position FROM `position` WHERE name_position = 'Начальник цеха') THEN
                UPDATE workshop SET chief_workshop = NEW.id_person WHERE id_workshop = NEW.workshop_job;
            END IF;
            
            -- Если стал начальником участка - устанавливаем ссылку
            IF NEW.position_person = (SELECT id_position FROM `position` WHERE name_position = 'Начальник участка') THEN
                UPDATE section SET chief_section = NEW.id_person WHERE id_section = NEW.section_job;
            END IF;
            
            -- Если стал бригадиром - устанавливаем ссылку
            IF NEW.position_person = (SELECT id_position FROM `position` WHERE name_position = 'Бригадир') THEN
                UPDATE brigade SET foreman_brigade = NEW.id_person WHERE id_brigade = NEW.brigade_job;
            END IF;
        END IF;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_update_person` BEFORE UPDATE ON `person` FOR EACH ROW BEGIN
    DECLARE workshop_exists INT;
    DECLARE section_exists INT;
    DECLARE brigade_exists INT;
    DECLARE position_chief_workshop INT;
    DECLARE position_chief_section INT;
    DECLARE position_foreman_brigade INT;
    DECLARE position_tester INT;
    
    -- Проверка неизменяемых полей (только если они действительно изменились)
    IF (NEW.id_person != OLD.id_person) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Нельзя изменять id_person!';
    END IF;
    
    IF (NEW.surname != OLD.surname OR 
        NEW.name != OLD.name OR 
        NEW.patronymic != OLD.patronymic) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Нельзя изменять ФИО!';
    END IF;
    
    IF (NEW.gender != OLD.gender) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Нельзя изменять пол!';
    END IF;
    
    IF (NEW.birthday != OLD.birthday) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Нельзя изменять дату рождения!';
    END IF;
    
    -- Дальше идут все ваши проверки (как в триггере на вставку)
    SELECT id_position INTO position_tester 
    FROM `position` 
    WHERE name_position = 'Испытатель';
    
    SELECT id_position INTO position_chief_workshop 
    FROM `position` 
    WHERE name_position = 'Начальник цеха';
    
    SELECT id_position INTO position_chief_section 
    FROM `position` 
    WHERE name_position = 'Начальник участка';
    
    SELECT id_position INTO position_foreman_brigade 
    FROM `position` 
    WHERE name_position = 'Бригадир';
    
    IF NEW.section_job IS NOT NULL THEN
        SELECT COUNT(*) INTO section_exists 
        FROM section 
        WHERE id_section = NEW.section_job;
    END IF;
    
    SELECT COUNT(*) INTO workshop_exists 
    FROM workshop 
    WHERE id_workshop = NEW.workshop_job;
    
    -- Проверка соответствия образования и категории персонала
    IF NEW.education = 'Высшее' AND 
    (SELECT name_staff_category FROM staff_category WHERE id_staff_category = 
     (SELECT staff_category_position FROM `position` WHERE id_position=NEW.position_person )) = 'Рабочий персонал' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Человек с высшим образованием не может занимать должность с категорией "Рабочий персонал" !';
    END IF;
    
    IF NEW.education = 'Среднее специальное' AND 
    (SELECT name_staff_category FROM staff_category WHERE id_staff_category = 
     (SELECT staff_category_position FROM `position` WHERE id_position=NEW.position_person )) = 'Инженерно-технический персонал' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Человек со средним специальным образованием не может занимать должность с категорией "Инженерно-технический персонал" !';
    END IF;
    
    -- Проверки для инженерно-технического персонала
    IF NEW.workshop_job IS NOT NULL AND NEW.position_person != position_tester THEN
        IF NEW.education='Высшее' THEN
            IF NEW.brigade_job IS NOT NULL THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У инженерно-технического персонала не должно быть бригады!';
            END IF;
            
            IF NEW.position_person = position_chief_workshop THEN
                IF workshop_exists=0 THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: Такого цеха не существует!';
                END IF;
                
                IF (SELECT chief_workshop FROM workshop WHERE id_workshop=NEW.workshop_job) IS NOT NULL 
                   AND (SELECT chief_workshop FROM workshop WHERE id_workshop=NEW.workshop_job) != OLD.id_person THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: У этого цеха уже есть начальник!';
                END IF;
                
                IF NEW.section_job IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: У начальника цеха не должно быть участка!';
                END IF;
            ELSEIF NEW.section_job IS NOT NULL THEN
                IF section_exists=0 THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: Такого участка не существует!';
                END IF;
                
                IF NEW.workshop_job != (SELECT id_workshop_section FROM section WHERE id_section=NEW.section_job) THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: В указанном цехе нет такого участка!';
                END IF;

                IF NEW.position_person = position_chief_section THEN
                    IF (SELECT chief_section FROM section WHERE id_section=NEW.section_job) IS NOT NULL 
                       AND (SELECT chief_section FROM section WHERE id_section=NEW.section_job) != OLD.id_person THEN
                        SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'ОШИБКА: У этого участка уже есть начальник!';
                    END IF;
                END IF;
            ELSE
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У инженерно-технического персонала должен быть участок! (Исключение: Начальник цеха)';
            END IF;
        ELSEIF NEW.education='Среднее специальное' THEN
            -- Проверки для рабочего персонала
            IF NEW.brigade_job IS NULL THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У рабочего персонала должна быть бригада!';
            END IF;
            
            IF NEW.section_job IS NULL THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У рабочего персонала должен быть участок!';
            END IF;
            
            SELECT COUNT(*) INTO brigade_exists 
            FROM brigade 
            WHERE id_brigade = NEW.brigade_job;
            
            IF workshop_exists=0 THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: Такого цеха не существует!';
            END IF;
            
            IF section_exists=0 THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: Такого участка не существует!';
            END IF;
            
            IF brigade_exists=0 THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: Такой бригады не существует!';
            END IF;
            
            IF NEW.workshop_job != (SELECT id_workshop_section FROM section WHERE id_section=NEW.section_job) THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: В указанном цехе нет такого участка!';
            END IF;
            
            IF NEW.section_job != (SELECT id_section_brigade FROM brigade WHERE id_brigade=NEW.brigade_job) THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: В указанном участке нет такой бригады!';
            END IF;
            
            IF NEW.position_person = position_foreman_brigade THEN
                IF (SELECT foreman_brigade FROM brigade WHERE id_brigade=NEW.brigade_job) IS NOT NULL 
                   AND (SELECT foreman_brigade FROM brigade WHERE id_brigade=NEW.brigade_job) != OLD.id_person THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: У этой бригады уже есть бригадир!';
                END IF;
            END IF;
        END IF;
    ELSEIF NEW.position_person = position_tester THEN
        -- Проверки для испытателя
        IF NEW.brigade_job IS NOT NULL OR 
           NEW.section_job IS NOT NULL OR
           NEW.workshop_job IS NOT NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'ОШИБКА: У испытателя не должно быть ни цеха, ни участка, ни бригады';
        END IF;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ОШИБКА: Цех должен быть указан у всех должностей (Исключение: Испытатель)';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `try_insert_person` BEFORE INSERT ON `person` FOR EACH ROW BEGIN
    DECLARE workshop_exists INT;
    DECLARE section_exists INT;
    DECLARE brigade_exists INT;
    DECLARE position_tester INT;
    DECLARE position_chief_workshop INT;
    DECLARE position_chief_section INT;
    DECLARE position_foreman_brigade INT;
    DECLARE error_message VARCHAR(255);
    DECLARE staff_category_name VARCHAR(50);
    
    -- Получаем ID должностей
    SELECT id_position INTO position_tester FROM `position` WHERE name_position = 'Испытатель';
    SELECT id_position INTO position_chief_workshop FROM `position` WHERE name_position = 'Начальник цеха';
    SELECT id_position INTO position_chief_section FROM `position` WHERE name_position = 'Начальник участка';
    SELECT id_position INTO position_foreman_brigade FROM `position` WHERE name_position = 'Бригадир';
    
    -- Проверка соответствия образования и должности
    CALL check_education_position_match(NEW.education, NEW.position_person, error_message);
    IF error_message IS NOT NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
    END IF;
    
    -- Проверка для испытателей
    IF NEW.position_person = position_tester THEN
        IF NEW.brigade_job IS NOT NULL OR NEW.section_job IS NOT NULL OR NEW.workshop_job IS NOT NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'ОШИБКА: У испытателя не должно быть ни цеха, ни участка, ни бригады';
        END IF;
    ELSE
        -- Проверка обязательности указания цеха
        IF NEW.workshop_job IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'ОШИБКА: Цех должен быть указан у всех должностей (Исключение: Испытатель)';
        END IF;
        
        -- Проверка валидности цеха
        CALL check_workshop_validity(NEW.workshop_job, workshop_exists, error_message);
        IF error_message IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
        END IF;
        
        -- Проверка для инженерно-технического персонала (высшее образование)
        IF NEW.education = 'Высшее' THEN
            IF NEW.brigade_job IS NOT NULL THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У инженерно-технического персонала не должно быть бригады!';
            END IF;
            
            -- Проверка для начальника цеха
            IF NEW.position_person = position_chief_workshop THEN
                CALL check_chief_workshop(NEW.id_person, NEW.workshop_job, error_message);
                IF error_message IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
                END IF;
                
                IF NEW.section_job IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: У начальника цеха не должно быть участка!';
                END IF;
            ELSE
                -- Проверка для остального инженерно-технического персонала
                IF NEW.section_job IS NULL THEN
                    SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'ОШИБКА: У инженерно-технического персонала должен быть участок! (Исключение: Начальник цеха)';
                ELSE
                    -- Проверка валидности участка
                    CALL check_section_validity(NEW.section_job, NEW.workshop_job, section_exists, error_message);
                    IF error_message IS NOT NULL THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
                    END IF;
                    
                    -- Проверка для начальника участка
                    IF NEW.position_person = position_chief_section THEN
                        CALL check_chief_section(NEW.id_person, NEW.section_job, error_message);
                        IF error_message IS NOT NULL THEN
                            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
                        END IF;
                    END IF;
                END IF;
            END IF;
        -- Проверка для рабочего персонала (среднее специальное образование)
        ELSEIF NEW.education = 'Среднее специальное' THEN
            IF NEW.brigade_job IS NULL THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У рабочего персонала должна быть бригада!';
            END IF;
            
            IF NEW.section_job IS NULL THEN
                SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'ОШИБКА: У рабочего персонала должен быть участок!';
            ELSE
                -- Проверка валидности участка
                CALL check_section_validity(NEW.section_job, NEW.workshop_job, section_exists, error_message);
                IF error_message IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
                END IF;
                
                -- Проверка валидности бригады
                CALL check_brigade_validity(NEW.brigade_job, NEW.section_job, brigade_exists, error_message);
                IF error_message IS NOT NULL THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
                END IF;
                
                -- Проверка для бригадира
                IF NEW.position_person = position_foreman_brigade THEN
                    CALL check_foreman_brigade(NEW.id_person, NEW.brigade_job, error_message);
                    IF error_message IS NOT NULL THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
                    END IF;
                END IF;
            END IF;
        END IF;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `person_characteristic_person`
--

CREATE TABLE `person_characteristic_person` (
  `id_person_psp` int NOT NULL,
  `id_characteristic_person_psp` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `person_characteristic_person`
--

INSERT INTO `person_characteristic_person` (`id_person_psp`, `id_characteristic_person_psp`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(13, 1),
(14, 1),
(15, 1),
(21, 1),
(22, 1),
(29, 1),
(30, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(3, 2),
(4, 2),
(5, 2),
(6, 2),
(13, 2),
(14, 2),
(15, 2),
(21, 2),
(22, 2),
(29, 2),
(30, 2),
(33, 2),
(34, 2),
(35, 2),
(36, 2),
(37, 2),
(38, 2),
(39, 2),
(40, 2),
(1, 3),
(2, 3),
(29, 7),
(30, 7),
(33, 7),
(36, 7),
(37, 7),
(40, 7),
(13, 8),
(14, 8),
(15, 8),
(21, 8),
(22, 8),
(33, 8),
(34, 8),
(37, 8),
(38, 8),
(13, 12),
(14, 12),
(15, 12),
(21, 12),
(22, 12),
(29, 12),
(30, 12),
(1, 13),
(2, 13),
(3, 13),
(4, 13),
(5, 13),
(6, 13),
(35, 14),
(39, 14),
(1, 15),
(2, 15),
(3, 15),
(4, 15),
(5, 15),
(6, 15),
(13, 15),
(14, 15),
(15, 15),
(21, 15),
(22, 15),
(33, 15),
(34, 15),
(35, 15),
(36, 15),
(37, 15),
(38, 15),
(39, 15),
(40, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `person_movement`
--

CREATE TABLE `person_movement` (
  `id_movement` int NOT NULL,
  `id_person_movement` int NOT NULL,
  `action` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `old_position` int DEFAULT NULL,
  `new_position` int DEFAULT NULL,
  `old_workshop` int DEFAULT NULL,
  `new_workshop` int DEFAULT NULL,
  `old_section` int DEFAULT NULL,
  `new_section` int DEFAULT NULL,
  `old_brigade` int DEFAULT NULL,
  `new_brigade` int DEFAULT NULL,
  `movement_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `person_movement`
--

INSERT INTO `person_movement` (`id_movement`, `id_person_movement`, `action`, `old_position`, `new_position`, `old_workshop`, `new_workshop`, `old_section`, `new_section`, `old_brigade`, `new_brigade`, `movement_date`) VALUES
(1, 1, 'Принят на работу в должности Начальник цеха', NULL, 1, NULL, 1, NULL, NULL, NULL, NULL, '2025-05-12'),
(2, 2, 'Принят на работу в должности Начальник цеха', NULL, 1, NULL, 2, NULL, NULL, NULL, NULL, '2025-05-12'),
(3, 3, 'Принят на работу в должности Начальник участка', NULL, 2, NULL, 1, NULL, 1, NULL, NULL, '2025-05-12'),
(4, 4, 'Принят на работу в должности Начальник участка', NULL, 2, NULL, 1, NULL, 2, NULL, NULL, '2025-05-12'),
(5, 5, 'Принят на работу в должности Начальник участка', NULL, 2, NULL, 2, NULL, 3, NULL, NULL, '2025-05-12'),
(6, 6, 'Принят на работу в должности Начальник участка', NULL, 2, NULL, 2, NULL, 4, NULL, NULL, '2025-05-12'),
(7, 7, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 1, NULL, 1, NULL, 1, '2025-05-12'),
(8, 8, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 1, NULL, 1, NULL, 2, '2025-05-12'),
(9, 9, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 1, NULL, 2, NULL, 3, '2025-05-12'),
(10, 10, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 1, NULL, 2, NULL, 4, '2025-05-12'),
(11, 11, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 2, NULL, 3, NULL, 5, '2025-05-12'),
(12, 12, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 2, NULL, 3, NULL, 6, '2025-05-12'),
(13, 13, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 2, NULL, 4, NULL, 7, '2025-05-12'),
(14, 14, 'Принят на работу в должности Бригадир', NULL, 8, NULL, 2, NULL, 4, NULL, 8, '2025-05-12'),
(15, 15, 'Принят на работу в должности Испытатель', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-12'),
(16, 16, 'Принят на работу в должности Испытатель', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-12'),
(17, 17, 'Принят на работу в должности Испытатель', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-12'),
(18, 18, 'Принят на работу в должности Испытатель', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, '2025-05-12'),
(19, 19, 'Принят на работу в должности Мастер', NULL, 3, NULL, 1, NULL, 1, NULL, NULL, '2025-05-12'),
(20, 20, 'Принят на работу в должности Мастер', NULL, 3, NULL, 1, NULL, 1, NULL, NULL, '2025-05-12'),
(21, 21, 'Принят на работу в должности Мастер', NULL, 3, NULL, 1, NULL, 1, NULL, NULL, '2025-05-12'),
(22, 22, 'Принят на работу в должности Мастер', NULL, 3, NULL, 1, NULL, 2, NULL, NULL, '2025-05-12'),
(23, 23, 'Принят на работу в должности Мастер', NULL, 3, NULL, 1, NULL, 2, NULL, NULL, '2025-05-12'),
(24, 24, 'Принят на работу в должности Мастер', NULL, 3, NULL, 1, NULL, 2, NULL, NULL, '2025-05-12'),
(25, 25, 'Принят на работу в должности Мастер', NULL, 3, NULL, 2, NULL, 3, NULL, NULL, '2025-05-12'),
(26, 26, 'Принят на работу в должности Мастер', NULL, 3, NULL, 2, NULL, 3, NULL, NULL, '2025-05-12'),
(27, 27, 'Принят на работу в должности Мастер', NULL, 3, NULL, 2, NULL, 3, NULL, NULL, '2025-05-12'),
(28, 28, 'Принят на работу в должности Мастер', NULL, 3, NULL, 2, NULL, 4, NULL, NULL, '2025-05-12'),
(29, 29, 'Принят на работу в должности Мастер', NULL, 3, NULL, 2, NULL, 4, NULL, NULL, '2025-05-12'),
(30, 30, 'Принят на работу в должности Мастер', NULL, 3, NULL, 2, NULL, 4, NULL, NULL, '2025-05-12'),
(31, 31, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 1, NULL, 1, NULL, 1, '2025-05-12'),
(32, 32, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 1, NULL, 1, NULL, 1, '2025-05-12'),
(33, 33, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 1, NULL, 1, NULL, 1, '2025-05-12'),
(34, 34, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 1, NULL, 1, NULL, 1, '2025-05-12'),
(35, 35, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 1, NULL, 1, NULL, 2, '2025-05-12'),
(36, 36, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 1, NULL, 1, NULL, 2, '2025-05-12'),
(37, 37, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 1, NULL, 1, NULL, 2, '2025-05-12'),
(38, 38, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 1, NULL, 1, NULL, 2, '2025-05-12'),
(39, 39, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 1, NULL, 2, NULL, 3, '2025-05-12'),
(40, 40, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 1, NULL, 2, NULL, 3, '2025-05-12'),
(41, 41, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 1, NULL, 2, NULL, 3, '2025-05-12'),
(42, 42, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 1, NULL, 2, NULL, 3, '2025-05-12'),
(43, 43, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 1, NULL, 2, NULL, 4, '2025-05-12'),
(44, 44, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 1, NULL, 2, NULL, 4, '2025-05-12'),
(45, 45, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 1, NULL, 2, NULL, 4, '2025-05-12'),
(46, 46, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 1, NULL, 2, NULL, 4, '2025-05-12'),
(47, 47, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 2, NULL, 3, NULL, 5, '2025-05-12'),
(48, 48, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 2, NULL, 3, NULL, 5, '2025-05-12'),
(49, 49, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 2, NULL, 3, NULL, 5, '2025-05-12'),
(50, 50, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 2, NULL, 3, NULL, 5, '2025-05-12'),
(51, 51, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 2, NULL, 3, NULL, 6, '2025-05-12'),
(52, 52, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 2, NULL, 3, NULL, 6, '2025-05-12'),
(53, 53, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 2, NULL, 3, NULL, 6, '2025-05-12'),
(54, 54, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 2, NULL, 3, NULL, 6, '2025-05-12'),
(55, 55, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 2, NULL, 4, NULL, 7, '2025-05-12'),
(56, 56, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 2, NULL, 4, NULL, 7, '2025-05-12'),
(57, 57, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 2, NULL, 4, NULL, 7, '2025-05-12'),
(58, 58, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 2, NULL, 4, NULL, 7, '2025-05-12'),
(59, 59, 'Принят на работу в должности Электромонтер-монтажник', NULL, 4, NULL, 2, NULL, 4, NULL, 8, '2025-05-12'),
(60, 60, 'Принят на работу в должности Слесарь-сборщик кузовов', NULL, 5, NULL, 2, NULL, 4, NULL, 8, '2025-05-12'),
(61, 61, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 2, NULL, 4, NULL, 8, '2025-05-12'),
(62, 62, 'Принят на работу в должности Автомеханик', NULL, 7, NULL, 2, NULL, 4, NULL, 8, '2025-05-12'),
(64, 63, 'Уволен', 6, NULL, 1, NULL, 1, NULL, 1, NULL, '2025-05-14'),
(65, 64, 'Принят на работу в должности Оператор станков с ЧПУ', NULL, 6, NULL, 1, NULL, 1, NULL, 1, '2025-05-14');

-- --------------------------------------------------------

--
-- Структура таблицы `position`
--

CREATE TABLE `position` (
  `id_position` int NOT NULL,
  `name_position` varchar(100) NOT NULL,
  `staff_category_position` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `position`
--

INSERT INTO `position` (`id_position`, `name_position`, `staff_category_position`) VALUES
(1, 'Начальник цеха', 1),
(2, 'Начальник участка', 1),
(3, 'Мастер', 1),
(4, 'Электромонтер-монтажник', 2),
(5, 'Слесарь-сборщик кузовов', 2),
(6, 'Оператор станков с ЧПУ', 2),
(7, 'Автомеханик', 2),
(8, 'Бригадир', 2),
(9, 'Испытатель', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id_product` int NOT NULL,
  `category_product_product` int NOT NULL,
  `name_type_product` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id_product`, `category_product_product`, `name_type_product`) VALUES
(1, 1, 'Седан'),
(2, 1, 'Универсал'),
(3, 1, 'Хэтчбек'),
(4, 1, 'Лифтбэк'),
(5, 2, 'Тентованный'),
(6, 2, 'Цельнометаллический'),
(7, 2, 'Бортовой'),
(8, 3, 'Городской'),
(9, 3, 'Междугородный'),
(10, 3, 'Туристический'),
(11, 3, 'Школьный'),
(12, 4, 'Бульдозер'),
(13, 4, 'Автокран'),
(14, 4, 'Погрузчик'),
(15, 4, 'Дорожный каток'),
(16, 5, 'Спортбайк'),
(17, 5, 'Чоппер'),
(18, 5, 'Эндуро'),
(19, 5, 'Туристический');

-- --------------------------------------------------------

--
-- Структура таблицы `product_characteristic_product`
--

CREATE TABLE `product_characteristic_product` (
  `id_product_pcp` int NOT NULL,
  `id_characteristic_product_pcp` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product_characteristic_product`
--

INSERT INTO `product_characteristic_product` (`id_product_pcp`, `id_characteristic_product_pcp`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 5),
(1, 6),
(1, 7),
(1, 12),
(1, 13),
(2, 1),
(2, 2),
(2, 3),
(2, 5),
(2, 6),
(2, 7),
(2, 12),
(2, 13),
(3, 1),
(3, 2),
(3, 3),
(3, 5),
(3, 6),
(3, 7),
(3, 12),
(3, 13),
(4, 1),
(4, 2),
(4, 3),
(4, 5),
(4, 6),
(4, 7),
(4, 12),
(4, 13),
(5, 1),
(5, 3),
(5, 4),
(5, 5),
(5, 6),
(5, 11),
(5, 15),
(6, 1),
(6, 3),
(6, 4),
(6, 5),
(6, 6),
(6, 11),
(6, 15),
(7, 1),
(7, 3),
(7, 4),
(7, 5),
(7, 6),
(7, 11),
(7, 15),
(8, 1),
(8, 3),
(8, 5),
(8, 6),
(8, 9),
(8, 12),
(9, 1),
(9, 3),
(9, 5),
(9, 6),
(9, 9),
(9, 12),
(10, 1),
(10, 3),
(10, 5),
(10, 6),
(10, 9),
(10, 12),
(11, 1),
(11, 3),
(11, 5),
(11, 6),
(11, 9),
(11, 12),
(12, 4),
(12, 5),
(12, 6),
(12, 8),
(12, 11),
(13, 4),
(13, 5),
(13, 6),
(13, 8),
(13, 11),
(14, 4),
(14, 5),
(14, 6),
(14, 8),
(14, 11),
(15, 4),
(15, 5),
(15, 6),
(15, 8),
(15, 11),
(16, 1),
(16, 2),
(16, 5),
(16, 6),
(16, 11),
(17, 1),
(17, 2),
(17, 5),
(17, 6),
(17, 11),
(18, 1),
(18, 2),
(18, 5),
(18, 6),
(18, 8),
(18, 11),
(19, 1),
(19, 2),
(19, 5),
(19, 6),
(19, 11);

-- --------------------------------------------------------

--
-- Структура таблицы `section`
--

CREATE TABLE `section` (
  `id_section` int NOT NULL,
  `id_workshop_section` int NOT NULL,
  `chief_section` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `section`
--

INSERT INTO `section` (`id_section`, `id_workshop_section`, `chief_section`) VALUES
(1, 1, 3),
(2, 1, 4),
(3, 2, 5),
(4, 2, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `staff_category`
--

CREATE TABLE `staff_category` (
  `id_staff_category` int NOT NULL,
  `name_staff_category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `staff_category`
--

INSERT INTO `staff_category` (`id_staff_category`, `name_staff_category`) VALUES
(1, 'Инженерно-технический персонал'),
(2, 'Рабочий персонал');

-- --------------------------------------------------------

--
-- Структура таблицы `type_test`
--

CREATE TABLE `type_test` (
  `id_type_test` int NOT NULL,
  `laboratory_test` int NOT NULL,
  `name_type_test` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `type_test`
--

INSERT INTO `type_test` (`id_type_test`, `laboratory_test`, `name_type_test`) VALUES
(1, 1, 'Ускорение и торможение'),
(2, 1, 'Вибрационно-ударное испытание'),
(3, 2, 'Термоциклирование'),
(4, 2, 'Аэродинамическая труба'),
(5, 3, 'Расход топлива и выбросов'),
(6, 3, 'Шумность');

-- --------------------------------------------------------

--
-- Структура таблицы `work`
--

CREATE TABLE `work` (
  `id_work` int NOT NULL,
  `name_work` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `work`
--

INSERT INTO `work` (`id_work`, `name_work`) VALUES
(1, 'Сварка каркаса кузова'),
(2, 'Сборка двигателя'),
(3, 'Монтаж электрооборудования'),
(4, 'Установка механических компонентов'),
(5, 'Покраска кузова');

-- --------------------------------------------------------

--
-- Структура таблицы `workshop`
--

CREATE TABLE `workshop` (
  `id_workshop` int NOT NULL,
  `chief_workshop` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `workshop`
--

INSERT INTO `workshop` (`id_workshop`, `chief_workshop`) VALUES
(1, 1),
(2, 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `brigade`
--
ALTER TABLE `brigade`
  ADD PRIMARY KEY (`id_brigade`),
  ADD KEY `brigade_ibfk_2` (`foreman_brigade`),
  ADD KEY `brigade_ibfk_1` (`id_section_brigade`);

--
-- Индексы таблицы `category_product`
--
ALTER TABLE `category_product`
  ADD PRIMARY KEY (`id_category_product`);

--
-- Индексы таблицы `characteristic_person`
--
ALTER TABLE `characteristic_person`
  ADD PRIMARY KEY (`id_characteristic_person`);

--
-- Индексы таблицы `characteristic_product`
--
ALTER TABLE `characteristic_product`
  ADD PRIMARY KEY (`id_characteristic_product`);

--
-- Индексы таблицы `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id_equipment`);

--
-- Индексы таблицы `equipment_particular_test`
--
ALTER TABLE `equipment_particular_test`
  ADD PRIMARY KEY (`id_particular_test_ept`,`id_equipment_ept`),
  ADD KEY `id_equipment_ept` (`id_equipment_ept`);

--
-- Индексы таблицы `laboratory`
--
ALTER TABLE `laboratory`
  ADD PRIMARY KEY (`id_laboratory`);

--
-- Индексы таблицы `particular_product`
--
ALTER TABLE `particular_product`
  ADD PRIMARY KEY (`id_particular_product`),
  ADD KEY `id_workshop_pp` (`id_workshop_pp`),
  ADD KEY `id_section_pp` (`id_section_pp`),
  ADD KEY `id_brigade_pp` (`id_brigade_pp`),
  ADD KEY `id_product_pp` (`id_product_pp`);

--
-- Индексы таблицы `particular_test`
--
ALTER TABLE `particular_test`
  ADD PRIMARY KEY (`id_particular_test`),
  ADD KEY `id_person_pt` (`id_person_pt`),
  ADD KEY `id_type_test_pt` (`id_type_test_pt`),
  ADD KEY `id_particular_product_pt` (`id_particular_product_pt`);

--
-- Индексы таблицы `particular_work`
--
ALTER TABLE `particular_work`
  ADD PRIMARY KEY (`id_work_pw`,`id_particular_product_pw`),
  ADD KEY `id_particular_product_pw` (`id_particular_product_pw`);

--
-- Индексы таблицы `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id_person`),
  ADD KEY `person_ibfk_5` (`brigade_job`),
  ADD KEY `person_ibfk_6` (`workshop_job`),
  ADD KEY `person_ibfk_7` (`position_person`),
  ADD KEY `person_ibfk_4` (`section_job`);

--
-- Индексы таблицы `person_characteristic_person`
--
ALTER TABLE `person_characteristic_person`
  ADD PRIMARY KEY (`id_person_psp`,`id_characteristic_person_psp`),
  ADD KEY `id_characteristic_person_psp` (`id_characteristic_person_psp`);

--
-- Индексы таблицы `person_movement`
--
ALTER TABLE `person_movement`
  ADD PRIMARY KEY (`id_movement`),
  ADD KEY `new_brigade` (`new_brigade`),
  ADD KEY `new_section` (`new_section`),
  ADD KEY `new_workshop` (`new_workshop`),
  ADD KEY `new_position` (`new_position`),
  ADD KEY `old_brigade` (`old_brigade`),
  ADD KEY `old_section` (`old_section`),
  ADD KEY `old_workshop` (`old_workshop`),
  ADD KEY `old_position` (`old_position`),
  ADD KEY `person_movement_ibfk_1` (`id_person_movement`);

--
-- Индексы таблицы `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id_position`),
  ADD KEY `staff_category_position` (`staff_category_position`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id_product`),
  ADD KEY `category_product_product` (`category_product_product`);

--
-- Индексы таблицы `product_characteristic_product`
--
ALTER TABLE `product_characteristic_product`
  ADD PRIMARY KEY (`id_characteristic_product_pcp`,`id_product_pcp`),
  ADD KEY `id_product_pcp` (`id_product_pcp`);

--
-- Индексы таблицы `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`id_section`),
  ADD KEY `section_ibfk_2` (`chief_section`),
  ADD KEY `section_ibfk_1` (`id_workshop_section`);

--
-- Индексы таблицы `staff_category`
--
ALTER TABLE `staff_category`
  ADD PRIMARY KEY (`id_staff_category`);

--
-- Индексы таблицы `type_test`
--
ALTER TABLE `type_test`
  ADD PRIMARY KEY (`id_type_test`),
  ADD KEY `laboratory_test` (`laboratory_test`);

--
-- Индексы таблицы `work`
--
ALTER TABLE `work`
  ADD PRIMARY KEY (`id_work`);

--
-- Индексы таблицы `workshop`
--
ALTER TABLE `workshop`
  ADD PRIMARY KEY (`id_workshop`),
  ADD KEY `workshop_ibfk_1` (`chief_workshop`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `brigade`
--
ALTER TABLE `brigade`
  MODIFY `id_brigade` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `category_product`
--
ALTER TABLE `category_product`
  MODIFY `id_category_product` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `characteristic_person`
--
ALTER TABLE `characteristic_person`
  MODIFY `id_characteristic_person` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `characteristic_product`
--
ALTER TABLE `characteristic_product`
  MODIFY `id_characteristic_product` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id_equipment` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `laboratory`
--
ALTER TABLE `laboratory`
  MODIFY `id_laboratory` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `particular_product`
--
ALTER TABLE `particular_product`
  MODIFY `id_particular_product` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `particular_test`
--
ALTER TABLE `particular_test`
  MODIFY `id_particular_test` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `person`
--
ALTER TABLE `person`
  MODIFY `id_person` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT для таблицы `person_movement`
--
ALTER TABLE `person_movement`
  MODIFY `id_movement` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT для таблицы `position`
--
ALTER TABLE `position`
  MODIFY `id_position` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id_product` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `section`
--
ALTER TABLE `section`
  MODIFY `id_section` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `staff_category`
--
ALTER TABLE `staff_category`
  MODIFY `id_staff_category` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `type_test`
--
ALTER TABLE `type_test`
  MODIFY `id_type_test` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `work`
--
ALTER TABLE `work`
  MODIFY `id_work` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `workshop`
--
ALTER TABLE `workshop`
  MODIFY `id_workshop` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `brigade`
--
ALTER TABLE `brigade`
  ADD CONSTRAINT `brigade_ibfk_1` FOREIGN KEY (`id_section_brigade`) REFERENCES `section` (`id_section`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `brigade_ibfk_2` FOREIGN KEY (`foreman_brigade`) REFERENCES `person` (`id_person`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `equipment_particular_test`
--
ALTER TABLE `equipment_particular_test`
  ADD CONSTRAINT `equipment_particular_test_ibfk_1` FOREIGN KEY (`id_particular_test_ept`) REFERENCES `particular_test` (`id_particular_test`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `equipment_particular_test_ibfk_2` FOREIGN KEY (`id_equipment_ept`) REFERENCES `equipment` (`id_equipment`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `particular_product`
--
ALTER TABLE `particular_product`
  ADD CONSTRAINT `particular_product_ibfk_1` FOREIGN KEY (`id_workshop_pp`) REFERENCES `workshop` (`id_workshop`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `particular_product_ibfk_2` FOREIGN KEY (`id_section_pp`) REFERENCES `section` (`id_section`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `particular_product_ibfk_3` FOREIGN KEY (`id_brigade_pp`) REFERENCES `brigade` (`id_brigade`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `particular_product_ibfk_4` FOREIGN KEY (`id_product_pp`) REFERENCES `product` (`id_product`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `particular_test`
--
ALTER TABLE `particular_test`
  ADD CONSTRAINT `particular_test_ibfk_1` FOREIGN KEY (`id_person_pt`) REFERENCES `person` (`id_person`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `particular_test_ibfk_3` FOREIGN KEY (`id_type_test_pt`) REFERENCES `type_test` (`id_type_test`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `particular_test_ibfk_4` FOREIGN KEY (`id_particular_product_pt`) REFERENCES `particular_product` (`id_particular_product`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_ibfk_4` FOREIGN KEY (`section_job`) REFERENCES `section` (`id_section`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_ibfk_5` FOREIGN KEY (`brigade_job`) REFERENCES `brigade` (`id_brigade`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_ibfk_6` FOREIGN KEY (`workshop_job`) REFERENCES `workshop` (`id_workshop`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_ibfk_7` FOREIGN KEY (`position_person`) REFERENCES `position` (`id_position`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `person_characteristic_person`
--
ALTER TABLE `person_characteristic_person`
  ADD CONSTRAINT `person_characteristic_person_ibfk_1` FOREIGN KEY (`id_person_psp`) REFERENCES `person` (`id_person`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `person_characteristic_person_ibfk_2` FOREIGN KEY (`id_characteristic_person_psp`) REFERENCES `characteristic_person` (`id_characteristic_person`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `person_movement`
--
ALTER TABLE `person_movement`
  ADD CONSTRAINT `person_movement_ibfk_1` FOREIGN KEY (`id_person_movement`) REFERENCES `person` (`id_person`) ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_2` FOREIGN KEY (`new_brigade`) REFERENCES `brigade` (`id_brigade`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_3` FOREIGN KEY (`new_section`) REFERENCES `section` (`id_section`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_4` FOREIGN KEY (`new_workshop`) REFERENCES `workshop` (`id_workshop`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_5` FOREIGN KEY (`new_position`) REFERENCES `position` (`id_position`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_6` FOREIGN KEY (`old_brigade`) REFERENCES `brigade` (`id_brigade`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_7` FOREIGN KEY (`old_section`) REFERENCES `section` (`id_section`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_8` FOREIGN KEY (`old_workshop`) REFERENCES `workshop` (`id_workshop`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `person_movement_ibfk_9` FOREIGN KEY (`old_position`) REFERENCES `position` (`id_position`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `position`
--
ALTER TABLE `position`
  ADD CONSTRAINT `position_ibfk_1` FOREIGN KEY (`staff_category_position`) REFERENCES `staff_category` (`id_staff_category`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`category_product_product`) REFERENCES `category_product` (`id_category_product`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `product_characteristic_product`
--
ALTER TABLE `product_characteristic_product`
  ADD CONSTRAINT `product_characteristic_product_ibfk_1` FOREIGN KEY (`id_product_pcp`) REFERENCES `product` (`id_product`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `product_characteristic_product_ibfk_2` FOREIGN KEY (`id_characteristic_product_pcp`) REFERENCES `characteristic_product` (`id_characteristic_product`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `section`
--
ALTER TABLE `section`
  ADD CONSTRAINT `section_ibfk_1` FOREIGN KEY (`id_workshop_section`) REFERENCES `workshop` (`id_workshop`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `section_ibfk_2` FOREIGN KEY (`chief_section`) REFERENCES `person` (`id_person`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `type_test`
--
ALTER TABLE `type_test`
  ADD CONSTRAINT `type_test_ibfk_1` FOREIGN KEY (`laboratory_test`) REFERENCES `laboratory` (`id_laboratory`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `workshop`
--
ALTER TABLE `workshop`
  ADD CONSTRAINT `workshop_ibfk_1` FOREIGN KEY (`chief_workshop`) REFERENCES `person` (`id_person`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
